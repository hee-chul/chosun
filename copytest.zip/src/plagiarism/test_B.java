package plagiarism;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import plagiarism.testB;

public class test_B {
	
	public static List<List<String>> B_reader() throws IOException{
	
		String aa = testB.fileReader();		// 텍스트 가져오기			
		
		// 줄넘김, 쉼표 삭제
		String line = aa.replace(System.getProperty("line.separator"), "").replaceAll(",","").replaceAll("\"", "");
		String[] str = line.split("\\.");	// 마침표(".") 단위로 문장 나누기
		
		// 문장 앞뒤 공백 제거
		for (int i = 0; i < str.length; i++) {
			str[i] = str[i].trim();
		}
		
		List<List<String>> split = new ArrayList<List<String>>();	// 전체 문장을 나눠담을 배열
		for (int i = 0; i < str.length; i++) {
			String[] str2 = new String[str[i].split("\\s").length];
			str2 = str[i].split("\\s");								// 한문장을 어절별(띄어쓰기)로 나눔
			List<String> arr = new ArrayList<String>();			// 한문장을 나눠담을 배열
			
			for (int j = 0; j < str2.length; j++) {
				arr.add(str2[j]);
			}
			split.add(i, arr);
		}

//		System.out.println(split);

		return split;
	}
	
}
