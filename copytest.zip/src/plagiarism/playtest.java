package plagiarism;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

public class playtest {

	public static void main(String[] args){
		
		List<List<String>> doc_A = new ArrayList<List<String>>();
		List<List<String>> doc_B = new ArrayList<List<String>>();
		
		try {
			doc_A = test_A.A_reader();
			doc_B = test_B.B_reader();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<int[]> arr = new ArrayList<int[]>();	// 같은 문자열의 인덱스값
		List<int[]> arr2 = new ArrayList<int[]>();	// 연속어절 인덱스값
		
		List<int[]> brr = new ArrayList<int[]>();	// 같은 문자열의 인덱스값
		List<int[]> brr2 = new ArrayList<int[]>();	// 연속어절 인덱스값
		
		List<int[]> crr = new ArrayList<int[]>();	// A,B 같은문장 인덱스값
		List<int[]> crr2 = new ArrayList<int[]>();	// A,B 같은문장 인덱스값

		for (int i = 0; i < doc_A.size(); i++) {
			
			for (int j = 0; j < doc_B.size(); j++) {
				
				int cnt = 0;	// 문장의 60프로 이상인지
				int count = 0;	// 몇 어절이상 연속인지
				ArrayList<Integer> d_a = new ArrayList<Integer>();		// 일치하는 어절 인덱스 임시보관
				ArrayList<Integer> d_b = new ArrayList<Integer>();		// 일치하는 어절 인덱스 임시보관

				int red = 0;
				for (int i2 = 0; i2 < doc_A.get(i).size(); i2++) {
					
					
					for (int j2 = 0; j2 < doc_B.get(j).size(); j2++) {
						
						if(doc_A.get(i).get(i2).equals(doc_B.get(j).get(j2)) == true){
							count++;	// 문장에서 연속으로 일치하는 어절
							cnt++;		// 문장에서 일치하는 어절 수
							d_a.add(i2);
							d_b.add(j2);
							
							while(doc_A.get(i).size() > i2+1 && doc_B.get(j).size() > j2+1 
									&& doc_A.get(i).get(i2+1).equals(doc_B.get(j).get(j2+1)) == true){
								
								count++;
								i2++;
								j2++;
								cnt++;
								d_a.add(i2);
								d_b.add(j2);
								
							}	// while_i2,j2
							
							
							
							if( count >= 5 ){
								red++;
//								int[] d_a2 = new int[] {i2-count+1,i2};		// 연속 몇어절 이상인 인덱스 임시보관
//								int[] d_b2 = new int[] {j2-count+1,j2};		// 연속 몇어절 이상인 인덱스 임시보관
//								int[] d_c2 = new int[] {i,j};
//								
//								arr2.add(d_a2);
//								brr2.add(d_b2);
//								crr2.add(d_c2);
								
								int[] a = new int[] {i2-count+1,i2};
								int[] b = new int[] {j2-count+1,j2};
								int[] c = new int[] {i,j};
								
								arr.add(a);
								brr.add(b);
								crr.add(c);
								
								
							}	// if_count
							
							
						}	// if_equals
						
					}	// for_j2
				}	// for_i2
				
				double kk = doc_A.get(i).size();	// 문장의 어절 갯수
				double ck = cnt/kk;					// ( 문장에서 일치하는 어절 수 / 문장의 어절 갯수 )
				
				if( ck >= 0.6 && count < 5 ){	// 문장의 60프로 이상 유사할때
					
					int[] a = new int[d_a.size()+1];
					a[0] = -1;
					for (int k = 0; k < d_a.size(); k++) {
						a[k+1] = d_a.get(k);
					}
					
					int[] bb = new int[d_b.size()+1];
					bb[0] = -1;
					for (int k = 0; k < d_b.size(); k++) {
						bb[k+1] = d_b.get(k);
					}
							// ----- 중복 제거 ------
					TreeSet ts = new TreeSet();
					for (int k = 0; k < bb.length; k++) {
						ts.add(bb[k]);
					}
					
					int[] b = new int[d_b.size()+1];
					Iterator it = ts.iterator();
			        for (int k = 0; k < b.length; k++) {
						while ( it.hasNext() ) {
				            b[k] = (int) it.next();
				            k++;
				        }
			        }
			        		// -------------------
					int[] c = new int[] {i,j};
					
					arr.add(a);
					brr.add(b);
					crr.add(c);
				}	// else if_ck
				
				
				
			}	// for_j
		}	// for_i
		
	
//-------------------------------------------------------------------------------------
		// arr 값 확인
		for (int i = 0; i < arr.size(); i++) {
			System.out.println( "arr["+i+"] = "+Arrays.toString( arr.get(i) ) );
		}
			System.out.println("---------------");
		
		// brr 값 확인
		for (int i = 0; i < brr.size(); i++) {
			System.out.println(  "brr["+i+"] = "+Arrays.toString( brr.get(i) ) );
		}
		System.out.println("---------------");
		
		// crr 값 확인	
		for (int i = 0; i < crr.size(); i++) {
			System.out.println(  "crr["+i+"] = "+ Arrays.toString( crr.get(i) ) );
		}
//-------------------------------------------------------------------------------------
			
//			Map<String, List<int[]>> rrr = new HashMap<String, List<int[]>>();
//			
//			rrr.put("arr",arr);
//			rrr.put("brr",brr);
//			rrr.put("crr",crr);
		

		
	}

}


