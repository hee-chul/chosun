package plagiarism;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class testB {
	public static String fileReader() throws IOException{
		
//		JFileChooser chooser = new JFileChooser(); //객체 생성
//		   int ret = chooser.showOpenDialog(null);  //열기창 정의
//		   if (ret != JFileChooser.APPROVE_OPTION) {
//		    JOptionPane.showMessageDialog(null, "경로를 선택하지않았습니다.",
//		      "경고", JOptionPane.WARNING_MESSAGE);
//		   }
//		 			
//		   String filePath = chooser.getSelectedFile().getPath();  //파일경로를 가져옴
//		   System.out.println(filePath);  //출력
		
		String path = "D:/bbbb.txt";	// 파일경로
		StringBuilder sb = new StringBuilder(); // 파일 내용 저장을 위한 StringBuilder 객체 생성하기
		char character;
		
		BufferedReader fr = new BufferedReader(
								new InputStreamReader(new FileInputStream(path ),"euc-kr"));

		while( (character = (char)fr.read() ) != (char)-1 ){
			sb.append(character);
		}
		fr.close();
		
		return sb.toString();
	}

}


