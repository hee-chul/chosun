package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import plagiarism.test_A;
import plagiarism.test_B;

/**
 * Servlet implementation class slet004
 */
@WebServlet("/slet004")
public class slet004 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public slet004() {
        super();
        // TODO Auto-generated constructor stub
    }

    public static void reverseArrayInt(int[] array) {
        int temp;

        for (int i = 0; i < array.length / 2; i++) {
          temp = array[i];
          array[i] = array[(array.length - 1) - i];
          array[(array.length - 1) - i] = temp;
        }
      }

	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		List<List<String>> doc_A = new ArrayList<List<String>>();
		List<List<String>> doc_B = new ArrayList<List<String>>();
		
		try {
			doc_A = test_A.A_reader();
			doc_B = test_B.B_reader();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		req.setAttribute("doc_A", doc_A);
		req.setAttribute("doc_B", doc_B);
		
		int eojeol = 5;
		int non = 5;
		
		List<int[]> arr = new ArrayList<int[]>();	// 같은 문자열의 인덱스값
		List<int[]> arr2 = new ArrayList<int[]>();	// 비연속  문자열의 인덱스값
		
		List<int[]> brr = new ArrayList<int[]>();	// 같은 문자열의 인덱스값
		List<int[]> brr2 = new ArrayList<int[]>();	// 비연속 문자열의 인덱스값
		
		List<int[]> crr = new ArrayList<int[]>();	// A,B 같은문장 인덱스값
		List<int[]> crr2 = new ArrayList<int[]>();	// A,B 같은문장 인덱스값

		for (int i = 0; i < doc_A.size(); i++) {
			
			for (int j = 0; j < doc_B.size(); j++) {
				
				int cnt = 0;	// 문장에서 일치하는 어절 수
				ArrayList<Integer> d_a = new ArrayList<Integer>();
				ArrayList<Integer> d_b = new ArrayList<Integer>();
				ArrayList<Integer> eojeol_cnt = new ArrayList<Integer>();
				for (int i2 = 0; i2 < doc_A.get(i).size(); i2++) {
					
					int count = 0;	// 몇어절이상 연속인지
					for (int j2 = 0; j2 < doc_B.get(j).size(); j2++) {
						
						if(doc_A.get(i).get(i2).equals(doc_B.get(j).get(j2)) == true){
//							count++;	// 문장에서 연속으로 일치하는 어절
							cnt++;		// 문장에서 일치하는 어절 수
							d_a.add(i2);
							d_b.add(j2);

							while(doc_A.get(i).size() > i2+1 && doc_B.get(j).size() > j2+1 
									&& doc_A.get(i).get(i2+1).equals(doc_B.get(j).get(j2+1)) == true){
								
								++count;
								++i2;
								++j2;
								++cnt;
								d_a.add(i2);
								d_b.add(j2);
								
							}	// while_i2,j2
							eojeol_cnt.add(count);
							
							if( j2 == doc_B.get(j).size()-1 && cnt >= non ){
								
								//----- 각 문장의 count중 제일 큰 count 구하기
								int[] count_e = new int[eojeol_cnt.size()];
								for (int k = 0; k < count_e.length; k++) {
									count_e[k] = eojeol_cnt.get(k);
								}
								Arrays.sort(count_e);
								reverseArrayInt(count_e);
								count = count_e[0];
								//---------------------------------
								
								int[] a = new int[d_a.size()+1];
								a[0] = count+1;
								for (int k = 0; k < d_a.size(); k++) {
									a[k+1] = d_a.get(k);
								}
								
								int[] bb = new int[d_b.size()];

								for (int k = 0; k < d_b.size(); k++) {
									bb[k] = d_b.get(k);
								}
										// ----- 중복 제거 ------
								TreeSet ts = new TreeSet();
								for (int k = 0; k < bb.length; k++) {
									ts.add(bb[k]);
								}
								
								int[] b = new int[d_b.size()+1];
								b[0] = count+1;
								Iterator it = ts.iterator();
						        for (int k = 0; k < b.length; k++) {
									while ( it.hasNext() ) {
							            b[k+1] = (int) it.next();
							            k++;
							        }
						        }
						        		// -------------------
								int[] c = new int[] {i,j,count+1};
								
								arr.add(a);
								brr.add(b);
								crr.add(c);
								
							}	// if_(j2 == doc_B.get(j).size()-1)
							
							
						}	// if_equals
						
						
						
					}	// for_j2
					
					
				}	// for_i2
			}	// for_j
		}	// for_i
		
		
		for (int s = 0; s < arr.size(); s++) {
			
			if(arr.get(s)[0] >= eojeol){
				arr2.add(arr.get(s));
				brr2.add(brr.get(s));
				crr2.add(crr.get(s));
			}
			else if(arr.get(s)[0] < eojeol){
				for (int k = 1; k < arr.get(s).length; k++) {
					if( k+(2*non) < arr.get(s).length){
						
						int arr_non = arr.get(s)[k+(2*non)];
						int arr_k = arr.get(s)[k];
						
						if(arr_non - arr_k >= (2*non)+1  ){
							arr2.add(arr.get(s));
							brr2.add(brr.get(s));
							crr2.add(crr.get(s));
							break;
						}
					}
				}
			}
			
		}	// for_s
		
//-------------------------------------------------------------------------------------
		// arr2 값 확인
		for (int i = 0; i < arr2.size(); i++) {
			System.out.println( "arr2["+i+"] = "+Arrays.toString( arr2.get(i) ) );
		}
			System.out.println("---------------");
		
		// brr2 값 확인
		for (int i = 0; i < brr2.size(); i++) {
			System.out.println(  "brr2["+i+"] = "+Arrays.toString( brr2.get(i) ) );
		}
		System.out.println("---------------");
		
		// crr2 값 확인	
		for (int i = 0; i < crr2.size(); i++) {
			System.out.println(  "crr2["+i+"] = "+ Arrays.toString( crr2.get(i) ) );
		}
		System.out.println("---------------");
		System.out.println();
//-------------------------------------------------------------------------------------
		
		req.setAttribute("doc_A", doc_A);
		req.setAttribute("doc_B", doc_B);
		
		req.setAttribute("arr", arr2);
		req.setAttribute("brr", brr2);
		req.setAttribute("crr", crr2);
		
		req.setAttribute("eojeol", eojeol);
		req.setAttribute("non", non);

		RequestDispatcher rd = req.getRequestDispatcher("result3.jsp");
		rd.forward(req,resp);
		
		
	}

}
