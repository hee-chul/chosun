package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import plagiarism.test_A;
import plagiarism.test_B;

/**
 * Servlet implementation class slet03
 */
@WebServlet("/slet03")
public class slet03 extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public slet03() {
        super();
        // TODO Auto-generated constructor stub
    }


    
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		List<List<String>> doc_A = new ArrayList<List<String>>();
		List<List<String>> doc_B = new ArrayList<List<String>>();
		
		try {
			doc_A = test_A.A_reader();
			doc_B = test_B.B_reader();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		req.setAttribute("doc_A", doc_A);
		req.setAttribute("doc_B", doc_B);
		
		
//		int eojeol = Integer.parseInt(req.getParameter("eojeol"));
//		double percent = Double.parseDouble(req.getParameter("percent"));
		
		
		List<int[]> arr = new ArrayList<int[]>();	// 같은 문자열의 인덱스값
		List<int[]> brr = new ArrayList<int[]>();	// 같은 문자열의 인덱스값
		List<int[]> crr = new ArrayList<int[]>();	// A,B 같은문장 인덱스값

		for (int i = 0; i < doc_A.size(); i++) {
			
			for (int j = 0; j < doc_B.size(); j++) {
				
				int cnt = 0;	// 문장에서 일치하는 어절 수
				ArrayList<Integer> d_a = new ArrayList<Integer>();
				ArrayList<Integer> d_b = new ArrayList<Integer>();
				
				for (int i2 = 0; i2 < doc_A.get(i).size(); i2++) {
					
					int count = 0;	// 몇어절이상 연속인지
					for (int j2 = 0; j2 < doc_B.get(j).size(); j2++) {
						
						if(doc_A.get(i).get(i2).equals(doc_B.get(j).get(j2)) == true){
//							count++;	// 문장에서 연속으로 일치하는 어절
							cnt++;		// 문장에서 일치하는 어절 수
							d_a.add(i2);
							d_b.add(j2);
							
							while(doc_A.get(i).size() > i2+1 && doc_B.get(j).size() > j2+1 
									&& doc_A.get(i).get(i2+1).equals(doc_B.get(j).get(j2+1)) == true){
								
								count++;
								i2++;
								j2++;
								cnt++;
								d_a.add(i2);
								d_b.add(j2);
								
							}	// while_i2,j2
							
							double kk = doc_A.get(i).size();	// 문장의 어절 갯수
							double ck = cnt/kk;					// ( 문장에서 일치하는 어절 수 / 문장의 어절 갯수 )
							
							
//							if( count >= eojeol ){
//								int[] a = new int[] {i2-count+1,i2};
//								int[] b = new int[] {j2-count+1,j2};
//								int[] c = new int[] {i,j};
//								
//								arr.add(a);
//								brr.add(b);
//								crr.add(c);
//							}	// if_count
//							else if( count < eojeol
//										&& ck >= percent ){	// 문장의 percent 이상 유사할때
							if( j2 == doc_B.get(j).size()-1 ){
								if( ++count >= 5 || ck >= 0.5){
								
									int[] a = new int[d_a.size()+1];
									a[0] = count+1;
									for (int k = 0; k < d_a.size(); k++) {
										a[k+1] = d_a.get(k);
									}
									
									int[] bb = new int[d_b.size()];

									for (int k = 0; k < d_b.size(); k++) {
										bb[k] = d_b.get(k);
									}
											// ----- 중복 제거 ------
									TreeSet ts = new TreeSet();
									for (int k = 0; k < bb.length; k++) {
										ts.add(bb[k]);
									}
									
									int[] b = new int[d_b.size()+1];
									b[0] = count+1;
									Iterator it = ts.iterator();
							        for (int k = 0; k < b.length; k++) {
										while ( it.hasNext() ) {
								            b[k+1] = (int) it.next();
								            k++;
								        }
							        }
							        		// -------------------
									int[] c = new int[] {i,j,count+1};
									
									arr.add(a);
									brr.add(b);
									crr.add(c);
								}	// if_count,ck
							}	// if_(j2 == doc_B.get(j).size()-1)
							
						}	// if_equals
					}	// for_j2
				}	// for_i2
			}	// for_j
		}	// for_i
		
		
		
//-------------------------------------------------------------------------------------
		// arr 값 확인
		for (int i = 0; i < arr.size(); i++) {
			System.out.println( "arr["+i+"] = "+Arrays.toString( arr.get(i) ) );
		}
			System.out.println("---------------");
		
		// brr 값 확인
		for (int i = 0; i < brr.size(); i++) {
			System.out.println(  "brr["+i+"] = "+Arrays.toString( brr.get(i) ) );
		}
		System.out.println("---------------");
		
		// crr 값 확인	
		for (int i = 0; i < crr.size(); i++) {
			System.out.println(  "crr["+i+"] = "+ Arrays.toString( crr.get(i) ) );
		}
//-------------------------------------------------------------------------------------
		
		req.setAttribute("doc_A", doc_A);
		req.setAttribute("doc_B", doc_B);
		
		req.setAttribute("arr", arr);
		req.setAttribute("brr", brr);
		req.setAttribute("crr", crr);
		
//		req.setAttribute("eojeol", eojeol);
//		req.setAttribute("percent", percent);

		RequestDispatcher rd = req.getRequestDispatcher("result2.jsp");
		rd.forward(req,resp);
		
	}

}
