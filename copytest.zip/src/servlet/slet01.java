package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import plagiarism.test_A;
import plagiarism.test_B;
import plagiarism.toss;

/**
 * Servlet implementation class slet01
 */
@WebServlet("/slet01")
public class slet01 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public slet01() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		Map<String, List<int[]>> item = toss.toss();
		
		List<List<String>> doc_A = new ArrayList<List<String>>();
		List<List<String>> doc_B = new ArrayList<List<String>>();
		
		try {
			doc_A = test_A.A_reader();
			doc_B = test_B.B_reader();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		req.setAttribute("doc_A", doc_A);
		req.setAttribute("doc_B", doc_B);
		
		req.setAttribute("arr", item.get("arr"));
		req.setAttribute("brr", item.get("brr"));
		req.setAttribute("crr", item.get("crr"));
		
		RequestDispatcher rd = req.getRequestDispatcher("result.jsp");
		rd.forward(req,resp);
		
		
	}

	
}
