/**
 * Copyright (c) 2006-2012, JGraph Ltd */
package com.mxgraph.examples.swing;

import java.awt.Color;
import java.awt.Point;
import java.awt.print.PageFormat;
import java.awt.print.PrinterJob;
import java.net.URL;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.List;

import javax.swing.ImageIcon;

import org.w3c.dom.Document;

import com.mxgraph.examples.swing.editor.BasicGraphEditor;
import com.mxgraph.examples.swing.editor.EditorPalette;
import com.mxgraph.io.mxCodec;
import com.mxgraph.model.mxCell;
import com.mxgraph.model.mxGeometry;
import com.mxgraph.model.mxICell;
import com.mxgraph.model.mxIGraphModel;
import com.mxgraph.swing.mxGraphComponent;
import com.mxgraph.swing.util.mxGraphTransferable;
import com.mxgraph.util.mxEvent;
import com.mxgraph.util.mxEventObject;
import com.mxgraph.util.mxEventSource.mxIEventListener;
import com.mxgraph.util.mxPoint;
import com.mxgraph.util.mxUtils;
import com.mxgraph.view.mxCellState;
import com.mxgraph.view.mxGraph;

public class GraphEditor extends BasicGraphEditor
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4601740824088314699L;

	/**
	 * Holds the shared number formatter.
	 * 
	 * @see NumberFormat#getInstance()
	 */
	public static final NumberFormat numberFormat = NumberFormat.getInstance();

	/**
	 * Holds the URL for the icon to be used as a handle for creating new
	 * connections. This is currently unused.
	 */
	public static URL url = null;

	public GraphEditor()
	{
		this("개체관계 재구성", new CustomGraphComponent(new CustomGraph()));
	}

	/**
	 * 
	 */
	public GraphEditor(String appTitle, mxGraphComponent component)
	{
		super(appTitle, component);
		final mxGraph graph = graphComponent.getGraph();

		// Creates the shapes palette
		EditorPalette relationPalette = insertPalette("관계");
		EditorPalette humanPalette = insertPalette("사람");
		EditorPalette animalPalette = insertPalette("동물");
		EditorPalette plantPalette = insertPalette("식물");
		EditorPalette objectPalette = insertPalette("사물");

		// Sets the edge template to be used for creating new edges if an edge
		// is clicked in the shape palette
		relationPalette.addListener(mxEvent.SELECT, new mxIEventListener()
		{
			public void invoke(Object sender, mxEventObject evt)
			{
				Object tmp = evt.getProperty("transferable");

				if (tmp instanceof mxGraphTransferable)
				{
					mxGraphTransferable t = (mxGraphTransferable) tmp;
					Object cell = t.getCells()[0];

					if (graph.getModel().isEdge(cell))
					{
						((CustomGraph) graph).setEdgeTemplate(cell);
					}
				}
			}

		});

		// Adds some template cells for dropping into the graph
		//관계 탭
				ImageIcon charactor = new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/relation/rectangle.png"));
				charactor = new ImageIcon(charactor.getImage().getScaledInstance(32, 20, 0));
				
				relationPalette.addTemplate(
						"특징", charactor,
						"rectangle", 50, 20, "특징을 입력해 주세요");
				
				ImageIcon actor = new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/relation/actor.png"));
				actor = new ImageIcon(actor.getImage().getScaledInstance(20, 25, 0));

				relationPalette.addTemplate(
						"등장인물", actor,
						"shape=actor", 60, 80, "등장인물의 이름을 입력해 주세요");

				relationPalette.addEdgeTemplate("직선관계선",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/relation/straight.png")),
						"straight", 80, 80, "관계를 입력해 주세요");

				relationPalette.addEdgeTemplate("수평관계선",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/relation/connect.png")), null,
						80, 80, "관계를 입력해 주세요");

				relationPalette.addEdgeTemplate("수직관계선",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/relation/vertical.png")),
						"vertical", 80, 80, "관계를 입력해 주세요");

				relationPalette.addEdgeTemplate("개체관계선",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/relation/entity.png")), "entity",
						80, 80, "관계를 입력해 주세요");

		//사람 탭
				humanPalette.addTemplate("남자1",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/human/male_1.png")),
						"image;image=/com/mxgraph/examples/swing/images/human/male_1.png", 50, 80, "");
				
				humanPalette.addTemplate("여자1",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/human/female_1.png")),
						"image;image=/com/mxgraph/examples/swing/images/human/female_1.png", 50, 80, "");
				
				humanPalette.addTemplate("남자아이",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/human/boy.png")),
						"image;image=/com/mxgraph/examples/swing/images/human/boy.png", 50, 80, "");
				
				humanPalette.addTemplate("여자아이",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/human/girl.png")),
						"image;image=/com/mxgraph/examples/swing/images/human/girl.png", 50, 80, "");
				
				humanPalette.addTemplate("할아버지",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/human/grandpa.png")),
						"image;image=/com/mxgraph/examples/swing/images/human/grandpa.png", 50, 80, "");
				
				humanPalette.addTemplate("할머니",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/human/grandma.png")),
						"image;image=/com/mxgraph/examples/swing/images/human/grandma.png", 50, 80, "");
				
				humanPalette.addTemplate("남자2",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/human/male_2.png")),
						"image;image=/com/mxgraph/examples/swing/images/human/male_2.png", 50, 80, "");
				
				humanPalette.addTemplate("여자2",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/human/female_2.png")),
						"image;image=/com/mxgraph/examples/swing/images/human/female_2.png", 50, 80, "");
				
				humanPalette.addTemplate("군중1",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/human/crowd_1.png")),
						"image;image=/com/mxgraph/examples/swing/images/human/crowd_1.png", 50, 80, "");
				
				humanPalette.addTemplate("군중2",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/human/crowd_2.png")),
						"image;image=/com/mxgraph/examples/swing/images/human/crowd_2.png", 50, 80, "");
				
		//동물 탭
				animalPalette.addTemplate("곰",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/animal/bear.png")),
						"image;image=/com/mxgraph/examples/swing/images/animal/bear.png", 80, 80, "");
				
				animalPalette.addTemplate("새",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/animal/bird.png")),
						"image;image=/com/mxgraph/examples/swing/images/animal/bird.png", 80, 80, "");
				
				animalPalette.addTemplate("말",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/animal/horse.png")),
						"image;image=/com/mxgraph/examples/swing/images/animal/horse.png", 80, 80, "");
				
				animalPalette.addTemplate("사자",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/animal/lion.png")),
						"image;image=/com/mxgraph/examples/swing/images/animal/lion.png", 80, 80, "");
				
				animalPalette.addTemplate("돼지",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/animal/pig.png")),
						"image;image=/com/mxgraph/examples/swing/images/animal/pig.png", 80, 80, "");
				
				animalPalette.addTemplate("토끼",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/animal/rabbit.png")),
						"image;image=/com/mxgraph/examples/swing/images/animal/rabbit.png", 80, 80, "");
				
				animalPalette.addTemplate("쥐",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/animal/rat.png")),
						"image;image=/com/mxgraph/examples/swing/images/animal/rat.png", 80, 80, "");
				
				animalPalette.addTemplate("호랑이",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/animal/tiger.png")),
						"image;image=/com/mxgraph/examples/swing/images/animal/tiger.png", 80, 80, "");
				
				animalPalette.addTemplate("거북이",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/animal/turtle.png")),
						"image;image=/com/mxgraph/examples/swing/images/animal/turtle.png", 80, 80, "");
				
				animalPalette.addTemplate("용",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/animal/dragon.png")),
						"image;image=/com/mxgraph/examples/swing/images/animal/dragon.png", 80, 80, "");
				
		//식물 탭
				
				plantPalette.addTemplate("선인장",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/plant/cactus.png")),
						"image;image=/com/mxgraph/examples/swing/images/plant/cactus.png", 80, 80, "");
				
				plantPalette.addTemplate("야자수나무",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/plant/palm.png")),
						"image;image=/com/mxgraph/examples/swing/images/plant/palm.png", 80, 80, "");
				
				plantPalette.addTemplate("나무1",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/plant/tree_big.png")),
						"image;image=/com/mxgraph/examples/swing/images/plant/tree_big.png", 80, 80, "");
				
				plantPalette.addTemplate("나무2",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/plant/tree_normal.png")),
						"image;image=/com/mxgraph/examples/swing/images/plant/tree_normal.png", 80, 80, "");
				
				plantPalette.addTemplate("나무3",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/plant/tree_thin.png")),
						"image;image=/com/mxgraph/examples/swing/images/plant/tree_thin.png", 80, 80, "");
				
				plantPalette.addTemplate("화분1",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/plant/flower_pot_1.png")),
						"image;image=/com/mxgraph/examples/swing/images/plant/flower_pot_1.png", 80, 80, "");
				
				plantPalette.addTemplate("화분2",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/plant/flower_pot_2.png")),
						"image;image=/com/mxgraph/examples/swing/images/plant/flower_pot_2.png", 80, 80, "");
				
				plantPalette.addTemplate("장미",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/plant/rose.png")),
						"image;image=/com/mxgraph/examples/swing/images/plant/rose.png", 80, 80, "");
				
				plantPalette.addTemplate("해바라기",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/plant/sun_flower.png")),
						"image;image=/com/mxgraph/examples/swing/images/plant/sun_flower.png", 80, 80, "");
				
				plantPalette.addTemplate("클로버",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/plant/clover.png")),
						"image;image=/com/mxgraph/examples/swing/images/plant/clover.png", 80, 80, "");

		//사물 탭		
				objectPalette.addTemplate("컵",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/object/cup.png")),
						"image;image=/com/mxgraph/examples/swing/images/object/cup.png", 80, 80, "");
				
				objectPalette.addTemplate("가구",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/object/furniture.png")),
						"image;image=/com/mxgraph/examples/swing/images/object/furniture.png", 80, 80, "");
				
				objectPalette.addTemplate("라디오",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/object/radio.png")),
						"image;image=/com/mxgraph/examples/swing/images/object/radio.png", 80, 80, "");
				
				objectPalette.addTemplate("텔레비전",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/object/tv.png")),
						"image;image=/com/mxgraph/examples/swing/images/object/tv.png", 80, 80, "");
				
				objectPalette.addTemplate("컴퓨터",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/object/computer.png")),
						"image;image=/com/mxgraph/examples/swing/images/object/computer.png", 80, 80, "");
				
				objectPalette.addTemplate("자동차",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/object/car.png")),
						"image;image=/com/mxgraph/examples/swing/images/object/car.png", 80, 80, "");
				
				objectPalette.addTemplate("우물",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/object/well.png")),
						"image;image=/com/mxgraph/examples/swing/images/object/well.png", 80, 80, "");
				
				objectPalette.addTemplate("집",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/object/house.png")),
						"image;image=/com/mxgraph/examples/swing/images/object/house.png", 80, 80, "");
				
				objectPalette.addTemplate("악세사리",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/object/acc.png")),
						"image;image=/com/mxgraph/examples/swing/images/object/acc.png", 80, 80, "");
				
				objectPalette.addTemplate("기타",
						new ImageIcon(GraphEditor.class.getResource("/com/mxgraph/examples/swing/images/object/guitar.png")),
						"image;image=/com/mxgraph/examples/swing/images/object/guitar.png", 80, 80, "");
		
		
		PrinterJob pj = PrinterJob.getPrinterJob();
		PageFormat format = pj.defaultPage();
		format.setOrientation(PageFormat.LANDSCAPE);
		pj.defaultPage(format);
		if (format != null)
		{
			graphComponent.setPageFormat(format); //graphComponent를 static으로 설정.
			graphComponent.zoomAndCenter(); //graphComponent를 static으로 설정.
			System.out.println("format != null");
		}		
	}

	/**
	 * 
	 */
	public static class CustomGraphComponent extends mxGraphComponent
	{

		/**
		 * 
		 */
		private static final long serialVersionUID = -6833603133512882012L;

		/**
		 * 
		 * @param graph
		 */
		public CustomGraphComponent(mxGraph graph)
		{
			super(graph);

			// Sets switches typically used in an editor
			setPageVisible(true);
			setGridVisible(true);
			setToolTips(true);
			getConnectionHandler().setCreateTarget(true);

			// Loads the defalt stylesheet from an external file
			mxCodec codec = new mxCodec();
			Document doc = mxUtils.loadDocument(GraphEditor.class.getResource(
					"/com/mxgraph/examples/swing/resources/basic-style.xml")
					.toString());
			codec.decode(doc.getDocumentElement(), graph.getStylesheet());

			// Sets the background to white
			getViewport().setOpaque(true);
			getViewport().setBackground(Color.WHITE);
		}

		/**
		 * Overrides drop behaviour to set the cell style if the target
		 * is not a valid drop target and the cells are of the same
		 * type (eg. both vertices or both edges). 
		 */
		public Object[] importCells(Object[] cells, double dx, double dy,
				Object target, Point location)
		{
			if (target == null && cells.length == 1 && location != null)
			{
				target = getCellAt(location.x, location.y);

				if (target instanceof mxICell && cells[0] instanceof mxICell)
				{
					mxICell targetCell = (mxICell) target;
					mxICell dropCell = (mxICell) cells[0];

					if (targetCell.isVertex() == dropCell.isVertex()
							|| targetCell.isEdge() == dropCell.isEdge())
					{
						mxIGraphModel model = graph.getModel();
						model.setStyle(target, model.getStyle(cells[0]));
						graph.setSelectionCell(target);

						return null;
					}
				}
			}

			return super.importCells(cells, dx, dy, target, location);
		}

	}

	/**
	 * A graph that creates new edges from a given template edge.
	 */
	public static class CustomGraph extends mxGraph
	{
		/**
		 * Holds the edge to be used as a template for inserting new edges.
		 */
		protected Object edgeTemplate;

		/**
		 * Custom graph that defines the alternate edge style to be used when
		 * the middle control point of edges is double clicked (flipped).
		 */
		public CustomGraph()
		{
			setAlternateEdgeStyle("edgeStyle=mxEdgeStyle.ElbowConnector;elbow=vertical");
		}

		/**
		 * Sets the edge template to be used to inserting edges.
		 */
		public void setEdgeTemplate(Object template)
		{
			edgeTemplate = template;
		}

		/**
		 * Prints out some useful information about the cell in the tooltip.
		 */
		public String getToolTipForCell(Object cell)
		{
			String tip = "<html>";
			mxGeometry geo = getModel().getGeometry(cell);
			mxCellState state = getView().getState(cell);

			if (getModel().isEdge(cell))
			{
				tip += "points={";

				if (geo != null)
				{
					List<mxPoint> points = geo.getPoints();

					if (points != null)
					{
						Iterator<mxPoint> it = points.iterator();

						while (it.hasNext())
						{
							mxPoint point = it.next();
							tip += "[x=" + numberFormat.format(point.getX())
									+ ",y=" + numberFormat.format(point.getY())
									+ "],";
						}

						tip = tip.substring(0, tip.length() - 1);
					}
				}

				tip += "}<br>";
				tip += "absPoints={";

				if (state != null)
				{

					for (int i = 0; i < state.getAbsolutePointCount(); i++)
					{
						mxPoint point = state.getAbsolutePoint(i);
						tip += "[x=" + numberFormat.format(point.getX())
								+ ",y=" + numberFormat.format(point.getY())
								+ "],";
					}

					tip = tip.substring(0, tip.length() - 1);
				}

				tip += "}";
			}
			else
			{
				tip += "geo=[";

				if (geo != null)
				{
					tip += "x=" + numberFormat.format(geo.getX()) + ",y="
							+ numberFormat.format(geo.getY()) + ",width="
							+ numberFormat.format(geo.getWidth()) + ",height="
							+ numberFormat.format(geo.getHeight());
				}

				tip += "]<br>";
				tip += "state=[";

				if (state != null)
				{
					tip += "x=" + numberFormat.format(state.getX()) + ",y="
							+ numberFormat.format(state.getY()) + ",width="
							+ numberFormat.format(state.getWidth())
							+ ",height="
							+ numberFormat.format(state.getHeight());
				}

				tip += "]";
			}

			mxPoint trans = getView().getTranslate();

			tip += "<br>scale=" + numberFormat.format(getView().getScale())
					+ ", translate=[x=" + numberFormat.format(trans.getX())
					+ ",y=" + numberFormat.format(trans.getY()) + "]";
			tip += "</html>";

			return tip;
		}

		/**
		 * Overrides the method to use the currently selected edge template for
		 * new edges.
		 * 
		 * @param graph
		 * @param parent
		 * @param id
		 * @param value
		 * @param source
		 * @param target
		 * @param style
		 * @return
		 */
		public Object createEdge(Object parent, String id, Object value,
				Object source, Object target, String style)
		{
			if (edgeTemplate != null)
			{
				mxCell edge = (mxCell) cloneCells(new Object[] { edgeTemplate })[0];
				edge.setId(id);

				return edge;
			}

			return super.createEdge(parent, id, value, source, target, style);
		}

	}
}
