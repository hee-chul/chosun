package kr.ac.kaist.swrc.jhannanum.demo;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.List;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.print.PageFormat;
import java.awt.print.PrinterJob;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

import javax.swing.AbstractListModel;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import org.w3c.dom.Document;

import com.mxgraph.examples.swing.GraphEditor;
import com.mxgraph.examples.swing.editor.EditorMenuBar;
import com.mxgraph.io.mxCodec;
import com.mxgraph.swing.util.mxSwingConstants;
import com.mxgraph.util.mxConstants;
import com.mxgraph.util.mxResources;
import com.mxgraph.util.mxXmlUtils;
import com.mxgraph.util.png.mxPngTextDecoder;
import com.sun.org.apache.bcel.internal.generic.Select;

import javafx.scene.control.TextField;

public class multi extends JFrame implements MouseListener, ActionListener {

   protected static final DB1 DB1 = null;
   private JFrame frame;
   private JTextField txt_filepath;
   private JTextField textField_1;
   private JTextField nameTextField;
   private JTextField ageTextField;
   private JTextField genderTextField;
   private JTextField jobTextField;
   private JTextField birthTextField;
   private JTextField growTextField;
   private JTextField heightTextField;
   private JTextField weightTextField;
   private JTextField bodyTextField;
   private JTextField clothTextField;
   private JTextField itemTextField;
   private JTextField typeTextField;
   private JTextField habitTextField;
   private JTextField relationTextField;
   private JTextField targetTextField;
   private JButton btn_loadfile;
   private JList lst_select_noun;
   private DefaultListModel dmFileList = new DefaultListModel();
   private DefaultTableModel model;
   private Connection conn;
   private ResultSet rset;
   private PreparedStatement ps;
   private JTable table;
   private JScrollPane scroll;

   private JTextArea txtarea_editor;
   private File open_file_path;
   private JFileChooser jfc = new JFileChooser();
   
   private boolean complete = false;
   
   private JButton imageBtn;
   private String imageRoute;
   
   private boolean[] checkboxState = new boolean[15];
   private String[] checkboxString = {"이름", "나이", "성별", "직업","출생과정", "성장과정", "키", "몸무게", "외형적 특이점", "의상", "소품", "성격적 특성", "버릇/습관", "관계", "타겟"};
   private String[] checkboxSql = {"M_Name", "M_Age", "M_Sex", "M_Job", "M_Birth", "M_Grow", "M_Cm", "M_Kg", "M_Body", "M_Cloth", "M_Item", "M_Type", "M_Habit", "Relation", "Target"};
   
   private JSplitPane splitPane_3;
   private JPanel panel_12;
   private int Numb;
   
   String A;
   String B;
   
   
   //에디터
	private JPanel pan_editor;
	private JTextField textField;
	private JTextArea textArea;
	private JPanel editor_bot;
	
	public static JList list;
	static String[] values = {};
	ArrayList<String[]> tmp = new ArrayList<String[]>();  
	String textstring="";
	int count = 0;
   //에디터
   /**
    * Launch the application.
    */
   
   /**
    * Create the application.
    */
   public multi() {
	   for(int i = 0; i < checkboxState.length; i++) {
		   checkboxState[i] = false;
	   }
	   
	   checkboxState[0] = true;
	   checkboxState[11] = true;
	   checkboxState[13] = true;
	   checkboxState[14] = true;
	   
	   try { 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "project", "0412");
			System.out.println("multi 성공적으로 로딩완료");
			
		} catch (ClassNotFoundException e) {
			System.out.println("해당 드라이버를 찾을 수 없습니다.\n" + e);
		} catch (SQLException e) {
			System.out.println("해당 드라이버를 찾을 수 없습니다.\n" + e);
		}
	  
      initialize();
   }

   /**
    * Initialize the contents of the frame.
    */
   private void initialize() {
      frame = new JFrame(); 
      frame.setTitle("스토리텔링 지원 시스템");
      frame.setBounds(100, 100, 1082, 644);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.getContentPane().setLayout(new BorderLayout(0, 0));
      
      JMenuBar menuBar = new JMenuBar();
      frame.getContentPane().add(menuBar, BorderLayout.NORTH);
//--파일    
      JMenu mnFile = new JMenu(" 파일  ");
      menuBar.add(mnFile);
      
      JMenuItem mnFile_a = new JMenuItem("  새로만들기    ");
      JMenuItem mntmOpen = new JMenuItem("  열기    ");
      JMenuItem mnFile_c = new JMenuItem("  저장    ");
      JMenuItem mnFile_d = new JMenuItem("  다른 이름으로 저장     ");
      JMenuItem mnFile_e = new JMenuItem("  종료");
      
      mnFile.add(mnFile_a);
      mnFile.add(mntmOpen);
      mnFile.add(mnFile_c);
      mnFile.add(mnFile_d);
      mnFile.add(mnFile_e);
//--편집 
      JMenu pp = new JMenu(" 편집 ");
      menuBar.add(pp);
      
      JMenuItem pp_a = new JMenuItem("  실행 취소");
      JMenuItem pp_b = new JMenuItem("  잘라내기");
      JMenuItem pp_c = new JMenuItem("  복사");
      JMenuItem pp_d = new JMenuItem("  붙여넣기");
      JMenuItem pp_e = new JMenuItem("  찾기");
      JMenuItem pp_f = new JMenuItem("  모두 선택    ");
      
      pp.add(pp_a);
      pp.add(pp_b);
      pp.add(pp_c);
      pp.add(pp_d);
      pp.add(pp_e);
      pp.add(pp_f);
//--서식 
      JMenu qq = new JMenu(" 서식 ");
      menuBar.add(qq);
      
      JMenuItem qq_a = new JMenuItem("  자동 줄 바꿈    ");
      JMenuItem qq_b = new JMenuItem("  글꼴");
      
      qq.add(qq_a);
      qq.add(qq_b);
//--보기
      JMenu ww = new JMenu(" 보기 ");
      menuBar.add(ww);
      
      JMenuItem ww_a = new JMenuItem("  창 크기 재설정    ");
      JMenuItem ww_b = new JMenuItem("  전체 화면");
      
      ww.add(ww_a);
      ww.add(ww_b);
//--도구
      JMenu ee = new JMenu(" 도구 ");
      menuBar.add(ee);
      
      JMenuItem pyojeol = new JMenuItem("  표절 검사");
      JMenuItem ee_b = new JMenuItem("  문장 자동 완성    ");
      
      ee.add(pyojeol);
      ee.add(ee_b);
//--도움말
      JMenu rr = new JMenu(" 도움말 ");
      menuBar.add(rr);
      
      JMenuItem rr_a = new JMenuItem("  도움말 보기");
      JMenuItem rr_b = new JMenuItem("  프로그램 정보    ");
      
      rr.add(rr_a);
      rr.add(rr_b);
      ///////////////////////////////
//	?A="+A+"&B="+B
      // 표절버튼~
      class OpenUrlAction implements ActionListener {
        @Override public void actionPerformed(ActionEvent e) {
        	
			try {
				URI uri = new URI("http://localhost:8090/copytest/slet004");
				open(uri);
			} catch (URISyntaxException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        	
        }
      }
      
//      JPanel inspection = new JPanel();					// 에디터 박스안 표절버튼을 넣기위한 JPanel
//      pan_editor.add(inspection, BorderLayout.NORTH);
//      inspection.setLayout(new GridLayout(0, 2, 0, 0));
//      
//      JButton btn_inspection = new JButton("표절검사");
//      btn_inspection.setPreferredSize(new Dimension(30,23));
//      inspection.add(btn_inspection);
      
      
//      pyojeol.setText("<HTML><FONT color=\"#000099\"><U>표절검사</U></FONT></HTML>");
      pyojeol.setHorizontalAlignment(SwingConstants.LEFT);
      pyojeol.setBorderPainted(false);
      pyojeol.setOpaque(false);
      pyojeol.setBackground(Color.WHITE);
      pyojeol.addActionListener(new OpenUrlAction());
      
      // ~표절버튼
      
//--------------------------------------------------------------------------      
      

      
      JSplitPane splitPane = new JSplitPane();
      frame.getContentPane().add(splitPane);
      
      JSplitPane splitPane_2 = new JSplitPane();
      splitPane_2.setResizeWeight(0.3);
      splitPane.setLeftComponent(splitPane_2);
      splitPane.setResizeWeight(0.75);
      
      JPanel pan_plot_list = new JPanel();
      pan_plot_list.setBorder(new TitledBorder(null, "스토리", TitledBorder.LEADING, TitledBorder.TOP, null, null));
      splitPane_2.setLeftComponent(pan_plot_list);
      pan_plot_list.setLayout(new BorderLayout(0, 0));
      
      JTree tree = new JTree();
      tree.setModel(new DefaultTreeModel(
         new DefaultMutableTreeNode("플롯") {
            {
            }
         }
      ));
      pan_plot_list.add(tree, BorderLayout.CENTER);
      
      JPanel panel_19 = new JPanel();
      pan_plot_list.add(panel_19, BorderLayout.SOUTH);
      panel_19.setLayout(new GridLayout(0, 2, 0, 0));
      
      JButton button = new JButton("등위관계 추가");
      button.setPreferredSize(new Dimension(30, 23));
      panel_19.add(button);
      
      JButton btnNewButton = new JButton("하위관계추가");
      btnNewButton.setPreferredSize(new Dimension(30, 23));
      panel_19.add(btnNewButton);
      
      JButton btnNewButton_1 = new JButton("수정");
      btnNewButton_1.setPreferredSize(new Dimension(30, 23));
      panel_19.add(btnNewButton_1);
      
      JButton btnNewButton_2 = new JButton("삭제");
      btnNewButton_2.setPreferredSize(new Dimension(30, 23));
      panel_19.add(btnNewButton_2);
      
      
      
      //에디터
      	//1
		tmp.add(new String[] { "임금님", "왕자", "공주", "왕", "노인", "산적", "귀신", "아이", "산신령", "거지" });
		tmp.add(new String[] { "왕비", "왕", "왕자", "공주", "거지", "귀신", "도적", "산적", "노인", "산신령" });
		tmp.add(new String[] { "죽일", "집", "납치", "생포", "체험", "그림", "이야기", "소굴", "사진", "역할" });
		
		//2
		tmp.add(new String[] { "많은", "적은", "여러", "영리한", "소수의", "영특한", "똑똑한", "대부분", "섬기는", "아끼는" });
		tmp.add(new String[] { "신하", "왕", "왕자", "공주", "거지", "귀신", "도적", "산적", "노인", "산신령" });
		tmp.add(new String[] { "왕자", "귀신", "공주", "왕", "노인", "산적", "귀신", "아이", "산신령", "거지" });
		tmp.add(new String[] { "잡을", "생포", "죽일", "집", "사진", "그림", "이야기", "소굴", "체험", "역할" });
		tmp.add(new String[] { "사정", "꿈", "시간", "이름", "계획", "결과", "장소", "전략", "시세", "내용" });
		tmp.add(new String[] { "물어", "대화", "여쭤", "말하여", "세워", "지켜", "적어", "수립", "진행", "확정" });
		
		//3
		tmp.add(new String[] { "그", "이", "저", "요", "고", "조", "한", "다", "두", "거" });
		tmp.add(new String[] { "몫", "변", "상황", "역할", "책임", "일", "배당", "역할", "값", "임무" });
		tmp.add(new String[] { "지다", "담당하다", "따다", "얻다", "관장하다", "도맡다", "부담하다", "맡았다", "관리하다", "담임하다"});

		
		pan_editor = new JPanel();
		editor_bot = new JPanel();
		editor_bot.setLayout(new BorderLayout());
		
		textField = new JTextField();
//		textField.setColumns(65);
		textField.setPreferredSize(new Dimension(710, 190));
		textField.setText("");
		textField.addActionListener(this);
		textField.addKeyListener(new MyKeyListener());
		
		textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setColumns(30);
		textArea.setRows(45);
		textArea.requestFocus();
		
		pan_editor.setBorder(new TitledBorder(null, "에디터", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		pan_editor.setLayout(new BorderLayout());
		pan_editor.add(textArea, "North");		
		
		
		list = new JList(); // 텍스트입력시 아래 뜨게 만드는것은 J리스트를 사용하였음.
		list.setForeground(Color.BLUE);
		list.setBackground(new Color(239, 238, 238));
		list.setVisible(true);
		
		list.setModel(new AbstractListModel() { // 리스트에 들어갈 변수집합을 설정
			public int getSize() {
				return values.length; // 리스트 크기 반환
			}

			public Object getElementAt(int index) {
				return values[index];// 리스트에 내용접근시 필요한 index 정보 선정
			}
		});
		
		editor_bot.add(list, "East");
		editor_bot.add(textField, "West");
		
		pan_editor.add(editor_bot, "South");

//		list.setVisible(true); // 우선 안보이게 하기 위해 리스트를 기본적으로 false시켜놓음
		
		
		add(pan_editor);
		

		list.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				if (e.getClickCount() == 2) {
					textstring = textField.getText();
					textstring += " " + (String) list.getSelectedValue();
					textField.setText(textstring);
					textField.revalidate();
					textField.repaint();
					list.setVisible(false);
					textField.requestFocus();
					count = 0;
				}
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		
		splitPane_2.setRightComponent(pan_editor);

      //에디터
      
      JPanel pan_tab = new JPanel();
      splitPane.setRightComponent(pan_tab);
      pan_tab.setLayout(new BorderLayout(0, 0));
      
      final JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
      pan_tab.add(tabbedPane, BorderLayout.CENTER);
      
      JPanel pan_tab_ext_plot = new JPanel();
      tabbedPane.addTab("플롯 추출", null, pan_tab_ext_plot, null);
      pan_tab_ext_plot.setLayout(new BorderLayout(0, 0));
      
      JPanel pan_north_tab1 = new JPanel();
      pan_tab_ext_plot.add(pan_north_tab1, BorderLayout.NORTH);
      pan_north_tab1.setLayout(new BorderLayout(0, 0));
      
      txt_filepath = new JTextField();
      txt_filepath.setEnabled(false);
      txt_filepath.setHorizontalAlignment(SwingConstants.LEFT);
      pan_north_tab1.add(txt_filepath);
      txt_filepath.setColumns(10);
      
      btn_loadfile = new JButton("불러오기");
      pan_north_tab1.add(btn_loadfile, BorderLayout.EAST);
      btn_loadfile.addActionListener(this);
      
      JSplitPane splitPane_1 = new JSplitPane();
      splitPane_1.setResizeWeight(0.5);
      splitPane_1.setOrientation(JSplitPane.VERTICAL_SPLIT);
      pan_tab_ext_plot.add(splitPane_1, BorderLayout.CENTER);
      
      JPanel panel = new JPanel();
      splitPane_1.setLeftComponent(panel);
      panel.setLayout(new BorderLayout(0, 0));
      
      JPanel panel_1 = new JPanel();
      panel.add(panel_1, BorderLayout.NORTH);
      panel_1.setLayout(new GridLayout(0, 2, 0, 0));
      
      JComboBox comboBox = new JComboBox();
      comboBox.setModel(new DefaultComboBoxModel(new String[] {"사용자 명사 선택"}));
      panel_1.add(comboBox);
      
      JComboBox comboBox_1 = new JComboBox();
      comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"빈도수"}));
      panel_1.add(comboBox_1);
      
      lst_select_noun = new JList();
      panel.add(lst_select_noun, BorderLayout.CENTER);
      //////여기이
//      lst_select_noun.addMouseListener(this);
      
      lst_select_noun.addMouseListener(new MouseAdapter(){
    	  
    	  public void mouseClicked(MouseEvent e){
    		  
    		  textArea.append(lst_select_noun.getSelectedValue().toString() + "\n\n");
    		  System.out.println(lst_select_noun.getSelectedValue());
    		  System.out.println("으으");
    	  }
      });      
      
      
      
      
      JPanel panel_2 = new JPanel();
      splitPane_1.setRightComponent(panel_2);
      panel_2.setLayout(new BorderLayout(0, 0));
      
      JPanel panel_3 = new JPanel();
      panel_2.add(panel_3, BorderLayout.NORTH);
      panel_3.setLayout(new BorderLayout(0, 0));
      
      textField_1 = new JTextField();
      textField_1.setText("");
      panel_3.add(textField_1, BorderLayout.CENTER);
      textField_1.setColumns(10);
      
      JButton btn_search = new JButton("검     색");
      panel_3.add(btn_search, BorderLayout.EAST);
      
      JList lst_result_search = new JList();
      panel_2.add(lst_result_search, BorderLayout.CENTER);


//-------------------------------------------------------------------------------------------

      JPanel pan_tab_charactor = new JPanel();
      tabbedPane.addTab("인물(캐릭터)", null, pan_tab_charactor, null);
      pan_tab_charactor.setLayout(new BorderLayout(0, 0));
      
      
      JPanel panel_4 = new JPanel();
      pan_tab_charactor.add(panel_4);
      panel_4.setLayout(new BorderLayout(0, 0));
      
      splitPane_3 = new JSplitPane();
      splitPane_3.setResizeWeight(0.7); // 비율 수정
      splitPane_3.setPreferredSize(new Dimension(189, 20));
      splitPane_3.setOrientation(JSplitPane.VERTICAL_SPLIT);
      panel_4.add(splitPane_3, BorderLayout.CENTER);
      
      //////////////////////////////panel_5 높이 수정
      JPanel panel_5 = new JPanel();
      panel_5.setPreferredSize(new Dimension(20, 485));
      panel_5.setLayout(new BorderLayout(0, 0));
      /////////////////////////////////
      
      JScrollPane scrollPane = new JScrollPane(panel_5);
      scrollPane.setPreferredSize(new Dimension(12, 460));
      scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
      scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
      splitPane_3.setLeftComponent(scrollPane);
      panel_5.setLayout(new BorderLayout(0, 0));
      
      JPanel panel_7 = new JPanel();
      panel_5.add(panel_7, BorderLayout.NORTH);
      panel_7.setLayout(new BorderLayout(0, 0));
      
      JPanel panel_8 = new JPanel();
      panel_8.setBorder(new TitledBorder(null, "캐릭터 기본정보", TitledBorder.LEADING, TitledBorder.TOP, null, null));
      panel_7.add(panel_8, BorderLayout.NORTH);
      GridBagLayout gbl_panel_8 = new GridBagLayout();
      gbl_panel_8.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
      gbl_panel_8.rowHeights = new int[] {0, 0, 0, 0};
      gbl_panel_8.columnWeights = new double[]{0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 0.0, Double.MIN_VALUE, 0.0};
      gbl_panel_8.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0};
      panel_8.setLayout(gbl_panel_8);
      
      //////////////////////////////////////////////////////////////////////
      imageBtn = new JButton("");
      imageBtn.setPreferredSize(new Dimension(80, 100));
      GridBagConstraints gbc_imageBtn = new GridBagConstraints();
      gbc_imageBtn.insets = new Insets(0, 0, 5, 5);
      gbc_imageBtn.fill = GridBagConstraints.BOTH;
      gbc_imageBtn.gridwidth = 4;
      gbc_imageBtn.gridheight = 4;
      gbc_imageBtn.gridx = 0;
      gbc_imageBtn.gridy = 0;
      panel_8.add(imageBtn, gbc_imageBtn);
          
      imageBtn.addMouseListener(new MouseAdapter() {
         public void mouseClicked(MouseEvent e) {
            if(e.getButton() == e.BUTTON1) {
               imageRoute = showLoad();
               Image btnImage = showImage(imageRoute);
               btnImage = btnImage.getScaledInstance(imageBtn.getWidth(), imageBtn.getHeight(), java.awt.Image.SCALE_SMOOTH);
               
               ImageIcon ic = new ImageIcon(btnImage);
               imageBtn.setIcon(ic);
            }
            else if(e.getButton() == e.BUTTON3) {
               imageBtn.setIcon(null);
            }
         }
      });
      ///////////////////////////////////////////////////////////////////
      JLabel lblNewLabel = new JLabel("이   름");
      GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
      gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
      gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
      gbc_lblNewLabel.gridx = 4;
      gbc_lblNewLabel.gridy = 0;
      panel_8.add(lblNewLabel, gbc_lblNewLabel);
      
      nameTextField = new JTextField();
      GridBagConstraints gbc_nameTextField = new GridBagConstraints();
      gbc_nameTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_nameTextField.gridwidth = 6;
      gbc_nameTextField.insets = new Insets(0, 0, 5, 5);
      gbc_nameTextField.gridx = 5;
      gbc_nameTextField.gridy = 0;
      panel_8.add(nameTextField, gbc_nameTextField);
      nameTextField.setColumns(10);
      
      JCheckBox nameCheckBox = new JCheckBox("");
      nameCheckBox.setSelected(true);
      GridBagConstraints gbc_nameCheckBox = new GridBagConstraints();
      gbc_nameCheckBox.insets = new Insets(0, 0, 5, 0);
      gbc_nameCheckBox.gridx = 11;
      gbc_nameCheckBox.gridy = 0;
      panel_8.add(nameCheckBox, gbc_nameCheckBox);
      
      nameCheckBox.addItemListener(new ItemListener() {
		public void itemStateChanged(ItemEvent arg0) {
			if(!checkboxState[0]) {
				checkboxState[0] = true;
			}
			else checkboxState[0] = false;
			
			panel_12.removeAll();
			createCharacterlist();
		}
      });
      
      JLabel lblNewLabel_1 = new JLabel("나   이");
      GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
      gbc_lblNewLabel_1.anchor = GridBagConstraints.EAST;
      gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
      gbc_lblNewLabel_1.gridx = 4;
      gbc_lblNewLabel_1.gridy = 1;
      panel_8.add(lblNewLabel_1, gbc_lblNewLabel_1);
      
      ageTextField = new JTextField();
      GridBagConstraints gbc_ageTextField = new GridBagConstraints();
      gbc_ageTextField.gridwidth = 6;
      gbc_ageTextField.insets = new Insets(0, 0, 5, 5);
      gbc_ageTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_ageTextField.gridx = 5;
      gbc_ageTextField.gridy = 1;
      panel_8.add(ageTextField, gbc_ageTextField);
      ageTextField.setColumns(10);
      
      JCheckBox ageCheckBox = new JCheckBox("");
      GridBagConstraints gbc_ageCheckBox = new GridBagConstraints();
      gbc_ageCheckBox.insets = new Insets(0, 0, 5, 0);
      gbc_ageCheckBox.gridx = 11;
      gbc_ageCheckBox.gridy = 1;
      panel_8.add(ageCheckBox, gbc_ageCheckBox);
      
      ageCheckBox.addItemListener(new ItemListener() {
  		public void itemStateChanged(ItemEvent arg0) {
  			if(!checkboxState[1]) {
  				checkboxState[1] = true;
  			}
  			else checkboxState[1] = false;
  			
  			panel_12.removeAll();
			createCharacterlist();
  		}
  		});
      
      JLabel lblNewLabel_2 = new JLabel("성   별");
      GridBagConstraints gbc_lblNewLabel_2 = new GridBagConstraints();
      gbc_lblNewLabel_2.anchor = GridBagConstraints.EAST;
      gbc_lblNewLabel_2.insets = new Insets(0, 0, 5, 5);
      gbc_lblNewLabel_2.gridx = 4;
      gbc_lblNewLabel_2.gridy = 2;
      panel_8.add(lblNewLabel_2, gbc_lblNewLabel_2);
      
      genderTextField = new JTextField();
      GridBagConstraints gbc_genderTextField = new GridBagConstraints();
      gbc_genderTextField.gridwidth = 6;
      gbc_genderTextField.insets = new Insets(0, 0, 5, 5);
      gbc_genderTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_genderTextField.gridx = 5;
      gbc_genderTextField.gridy = 2;
      panel_8.add(genderTextField, gbc_genderTextField);
      genderTextField.setColumns(10);
      
      JCheckBox genderCheckBox = new JCheckBox("");
      genderCheckBox.setSelected(true);
      GridBagConstraints gbc_genderCheckBox = new GridBagConstraints();
      gbc_genderCheckBox.insets = new Insets(0, 0, 5, 0);
      gbc_genderCheckBox.gridx = 11;
      gbc_genderCheckBox.gridy = 2;
      panel_8.add(genderCheckBox, gbc_genderCheckBox);
      
      genderCheckBox.addItemListener(new ItemListener() {
    	  public void itemStateChanged(ItemEvent arg0) {
    			if(!checkboxState[2]) {
    				checkboxState[2] = true;
    			}
    			else checkboxState[2] = false;
    			
    			panel_12.removeAll();
    			createCharacterlist();
    		}
    	  });
      
      JLabel lblNewLabel_3 = new JLabel("직   업");
      GridBagConstraints gbc_lblNewLabel_3 = new GridBagConstraints();
      gbc_lblNewLabel_3.anchor = GridBagConstraints.EAST;
      gbc_lblNewLabel_3.insets = new Insets(0, 0, 5, 5);
      gbc_lblNewLabel_3.gridx = 4;
      gbc_lblNewLabel_3.gridy = 3;
      panel_8.add(lblNewLabel_3, gbc_lblNewLabel_3);
      
      jobTextField = new JTextField();
      GridBagConstraints gbc_jobTextField = new GridBagConstraints();
      gbc_jobTextField.gridwidth = 4;
      gbc_jobTextField.insets = new Insets(0, 0, 5, 5);
      gbc_jobTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_jobTextField.gridx = 5;
      gbc_jobTextField.gridy = 3;
      panel_8.add(jobTextField, gbc_jobTextField);
      jobTextField.setColumns(10);
      
      JComboBox comboBox_2 = new JComboBox();
      comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"직접입력", "무사", "공주"}));
      GridBagConstraints gbc_comboBox_2 = new GridBagConstraints();
      gbc_comboBox_2.gridwidth = 2;
      gbc_comboBox_2.insets = new Insets(0, 0, 5, 5);
      gbc_comboBox_2.gridx = 9;
      gbc_comboBox_2.gridy = 3;
      panel_8.add(comboBox_2, gbc_comboBox_2);
      
      JCheckBox jobCheckBox = new JCheckBox("");
      jobCheckBox.setSelected(true);
      GridBagConstraints gbc_jobCheckBox = new GridBagConstraints();
      gbc_jobCheckBox.insets = new Insets(0, 0, 5, 0);
      gbc_jobCheckBox.gridx = 11;
      gbc_jobCheckBox.gridy = 3;
      panel_8.add(jobCheckBox, gbc_jobCheckBox);
      
      jobCheckBox.addItemListener(new ItemListener() {
    	  public void itemStateChanged(ItemEvent arg0) {
    			if(!checkboxState[3]) {
    				checkboxState[3] = true;
    			}
    			else checkboxState[3] = false;
    			
    			panel_12.removeAll();
    			createCharacterlist();
    		}
    	  });
      
      JLabel label = new JLabel("출생과정");
      GridBagConstraints gbc_label = new GridBagConstraints();
      gbc_label.anchor = GridBagConstraints.EAST;
      gbc_label.insets = new Insets(0, 0, 5, 5);
      gbc_label.gridx = 4;
      gbc_label.gridy = 4;
      panel_8.add(label, gbc_label);
      
      birthTextField = new JTextField();
      GridBagConstraints gbc_birthTextField = new GridBagConstraints();
      gbc_birthTextField.insets = new Insets(0, 0, 5, 5);
      gbc_birthTextField.gridwidth = 6;
      gbc_birthTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_birthTextField.gridx = 5;
      gbc_birthTextField.gridy = 4;
      panel_8.add(birthTextField, gbc_birthTextField);
      birthTextField.setColumns(10);
      
      JCheckBox birthCheckBox = new JCheckBox("");
      GridBagConstraints gbc_birthCheckBox = new GridBagConstraints();
      gbc_birthCheckBox.insets = new Insets(0, 0, 5, 0);
      gbc_birthCheckBox.gridx = 11;
      gbc_birthCheckBox.gridy = 4;
      panel_8.add(birthCheckBox, gbc_birthCheckBox);
            
      birthCheckBox.addItemListener(new ItemListener() {
    	  public void itemStateChanged(ItemEvent arg0) {
    			if(!checkboxState[4]) {
    				checkboxState[4] = true;
    			}
    			else checkboxState[4] = false;
    			
    			panel_12.removeAll();
    			createCharacterlist();
    		}
    	  });
      
      JLabel lblNewLabel_4 = new JLabel("성장과정");
      GridBagConstraints gbc_lblNewLabel_4 = new GridBagConstraints();
      gbc_lblNewLabel_4.fill = GridBagConstraints.VERTICAL;
      gbc_lblNewLabel_4.anchor = GridBagConstraints.EAST;
      gbc_lblNewLabel_4.insets = new Insets(0, 0, 0, 5);
      gbc_lblNewLabel_4.gridx = 4;
      gbc_lblNewLabel_4.gridy = 5;
      panel_8.add(lblNewLabel_4, gbc_lblNewLabel_4);
      
      growTextField = new JTextField();
      GridBagConstraints gbc_growTextField = new GridBagConstraints();
      gbc_growTextField.insets = new Insets(0, 0, 0, 5);
      gbc_growTextField.gridwidth = 6;
      gbc_growTextField.fill = GridBagConstraints.BOTH;
      gbc_growTextField.gridx = 5;
      gbc_growTextField.gridy = 5;
      panel_8.add(growTextField, gbc_growTextField);
      growTextField.setColumns(10);
      
      JCheckBox growCheckBox = new JCheckBox("");
      GridBagConstraints gbc_growCheckBox = new GridBagConstraints();
      gbc_growCheckBox.gridx = 11;
      gbc_growCheckBox.gridy = 5;
      panel_8.add(growCheckBox, gbc_growCheckBox);
      
      growCheckBox.addItemListener(new ItemListener() {
    	  public void itemStateChanged(ItemEvent arg0) {
    			if(!checkboxState[5]) {
    				checkboxState[5] = true;
    			}
    			else checkboxState[5] = false;
    			
    			panel_12.removeAll();
    			createCharacterlist();
    		}
    	  });
      
      //////////////////////////////////////////////////////////
      JPanel panel_9 = new JPanel();
      panel_9.setBorder(new TitledBorder(null, "외형적 특징", TitledBorder.LEADING, TitledBorder.TOP, null, null));
      panel_7.add(panel_9, BorderLayout.CENTER);
      GridBagLayout gbl_panel_9 = new GridBagLayout();
      gbl_panel_9.columnWidths = new int[] {0, 0, 0, 0, 0, 0};
      gbl_panel_9.rowHeights = new int[] {0, 0};
      gbl_panel_9.columnWeights = new double[]{0.0, 1.0, 0.0, 0.0, 1.0, 0.0};
      gbl_panel_9.rowWeights = new double[]{0.0, 0.0, 0.0};
      panel_9.setLayout(gbl_panel_9);
      
      JLabel lblNewLabel_5 = new JLabel("키");
      GridBagConstraints gbc_lblNewLabel_5 = new GridBagConstraints();
      gbc_lblNewLabel_5.insets = new Insets(0, 0, 5, 5);
      gbc_lblNewLabel_5.anchor = GridBagConstraints.EAST;
      gbc_lblNewLabel_5.gridx = 0;
      gbc_lblNewLabel_5.gridy = 0;
      panel_9.add(lblNewLabel_5, gbc_lblNewLabel_5);
      
      heightTextField = new JTextField();
      GridBagConstraints gbc_heightTextField = new GridBagConstraints();
      gbc_heightTextField.insets = new Insets(0, 0, 5, 5);
      gbc_heightTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_heightTextField.gridx = 1;
      gbc_heightTextField.gridy = 0;
      panel_9.add(heightTextField, gbc_heightTextField);
      heightTextField.setColumns(1);
      
      JCheckBox heightCheckBox = new JCheckBox("");
      GridBagConstraints gbc_heightCheckBox = new GridBagConstraints();
      gbc_heightCheckBox.insets = new Insets(0, 0, 5, 5);
      gbc_heightCheckBox.gridx = 2;
      gbc_heightCheckBox.gridy = 0;
      panel_9.add(heightCheckBox, gbc_heightCheckBox);
      
      heightCheckBox.addItemListener(new ItemListener() {
    	  public void itemStateChanged(ItemEvent arg0) {
    			if(!checkboxState[6]) {
    				checkboxState[6] = true;
    			}
    			else checkboxState[6] = false;
    			
    			panel_12.removeAll();
    			createCharacterlist();
    		}
    	  });
      
      JLabel lblNewLabel_6 = new JLabel("몸무게");
      GridBagConstraints gbc_lblNewLabel_6 = new GridBagConstraints();
      gbc_lblNewLabel_6.insets = new Insets(0, 0, 5, 5);
      gbc_lblNewLabel_6.anchor = GridBagConstraints.EAST;
      gbc_lblNewLabel_6.gridx = 3;
      gbc_lblNewLabel_6.gridy = 0;
      panel_9.add(lblNewLabel_6, gbc_lblNewLabel_6);
      
      weightTextField = new JTextField();
      GridBagConstraints gbc_weightTextField = new GridBagConstraints();
      gbc_weightTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_weightTextField.insets = new Insets(0, 0, 5, 5);
      gbc_weightTextField.gridx = 4;
      gbc_weightTextField.gridy = 0;
      panel_9.add(weightTextField, gbc_weightTextField);
      weightTextField.setColumns(1);
      
      JCheckBox weightCheckBox = new JCheckBox("");
      GridBagConstraints gbc_weightCheckBox = new GridBagConstraints();
      gbc_weightCheckBox.insets = new Insets(0, 0, 5, 0);
      gbc_weightCheckBox.gridx = 5;
      gbc_weightCheckBox.gridy = 0;
      panel_9.add(weightCheckBox, gbc_weightCheckBox);
      weightCheckBox.addItemListener(new ItemListener() {
    	  public void itemStateChanged(ItemEvent arg0) {
    			if(!checkboxState[7]) {
    				checkboxState[7] = true;
    			}
    			else checkboxState[7] = false;
    			
    			panel_12.removeAll();
    			createCharacterlist();
    		}
    	  });
      
   
      
      //////////////////////////////////////////////////////////////////////////
      JLabel lblNewLabel_7 = new JLabel("외형적 특이점");
      GridBagConstraints gbc_lblNewLabel_7 = new GridBagConstraints();
      gbc_lblNewLabel_7.insets = new Insets(0, 0, 5, 5);
      gbc_lblNewLabel_7.gridx = 0;
      gbc_lblNewLabel_7.gridy = 1;
      panel_9.add(lblNewLabel_7, gbc_lblNewLabel_7);

      bodyTextField = new JTextField();
      GridBagConstraints gbc_bodyTextField = new GridBagConstraints();
      gbc_bodyTextField.gridwidth = 4;
      gbc_bodyTextField.insets = new Insets(0, 0, 5, 5);
      gbc_bodyTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_bodyTextField.gridx = 1;
      gbc_bodyTextField.gridy = 1;
      panel_9.add(bodyTextField, gbc_bodyTextField);
      bodyTextField.setColumns(1);
      
      JCheckBox bodyCheckBox = new JCheckBox("");
      GridBagConstraints gbc_bodyCheckBox = new GridBagConstraints();
      gbc_bodyCheckBox.insets = new Insets(0, 0, 5, 0);
      gbc_bodyCheckBox.gridx = 5;
      gbc_bodyCheckBox.gridy = 1;
      panel_9.add(bodyCheckBox, gbc_bodyCheckBox);    
      
      bodyCheckBox.addItemListener(new ItemListener() {
  	  public void itemStateChanged(ItemEvent arg0) {
  			if(!checkboxState[8]) {
  				checkboxState[8] = true;
  			}
  			else checkboxState[8] = false;
  			
  			panel_12.removeAll();
  			createCharacterlist();
  		}
  	  }); 
      
      JLabel label_1 = new JLabel("의상");
      GridBagConstraints gbc_label_1 = new GridBagConstraints();
      gbc_label_1.anchor = GridBagConstraints.EAST;
      gbc_label_1.insets = new Insets(0, 0, 0, 5);
      gbc_label_1.gridx = 0;
      gbc_label_1.gridy = 2;
      panel_9.add(label_1, gbc_label_1);
      
      clothTextField = new JTextField();
      GridBagConstraints gbc_clothTextField = new GridBagConstraints();
      gbc_clothTextField.insets = new Insets(0, 0, 0, 5);
      gbc_clothTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_clothTextField.gridx = 1;
      gbc_clothTextField.gridy = 2;
      panel_9.add(clothTextField, gbc_clothTextField);
      clothTextField.setColumns(1);
      
      JCheckBox clothCheckBox = new JCheckBox("");
      GridBagConstraints gbc_clothCheckBox = new GridBagConstraints();
      gbc_clothCheckBox.insets = new Insets(0, 0, 0, 5);
      gbc_clothCheckBox.gridx = 2;
      gbc_clothCheckBox.gridy = 2;
      panel_9.add(clothCheckBox, gbc_clothCheckBox);
      
      clothCheckBox.addItemListener(new ItemListener() {
    	  public void itemStateChanged(ItemEvent arg0) {
    			if(!checkboxState[9]) {
    				checkboxState[9] = true;
    			}
    			else checkboxState[9] = false;
    			
    			panel_12.removeAll();
    			createCharacterlist();
    		}
    	  });
      
      JLabel label_2 = new JLabel("소품");
      GridBagConstraints gbc_label_2 = new GridBagConstraints();
      gbc_label_2.insets = new Insets(0, 0, 0, 5);
      gbc_label_2.anchor = GridBagConstraints.EAST;
      gbc_label_2.gridx = 3;
      gbc_label_2.gridy = 2;
      panel_9.add(label_2, gbc_label_2);
      
      itemTextField = new JTextField();
      GridBagConstraints gbc_itemTextField = new GridBagConstraints();
      gbc_itemTextField.insets = new Insets(0, 0, 0, 5);
      gbc_itemTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_itemTextField.gridx = 4;
      gbc_itemTextField.gridy = 2;
      panel_9.add(itemTextField, gbc_itemTextField);
      itemTextField.setColumns(1);
      
      JCheckBox itemCheckBox = new JCheckBox("");
      GridBagConstraints gbc_itemCheckBox = new GridBagConstraints();
      gbc_itemCheckBox.gridx = 5;
      gbc_itemCheckBox.gridy = 2;
      panel_9.add(itemCheckBox, gbc_itemCheckBox);
      
      itemCheckBox.addItemListener(new ItemListener() {
    	  public void itemStateChanged(ItemEvent arg0) {
    			if(!checkboxState[10]) {
    				checkboxState[10] = true;
    			}
    			else checkboxState[10] = false;
    			
    			panel_12.removeAll();
    			createCharacterlist();
    		}
    	  });
    
 	  JPanel panel_10 = new JPanel();
      panel_10.setBorder(new TitledBorder(null, "내면적 특징", TitledBorder.LEADING, TitledBorder.TOP, null, null));
      panel_7.add(panel_10, BorderLayout.SOUTH);
      GridBagLayout gbl_panel_10 = new GridBagLayout();
      gbl_panel_10.columnWidths = new int[]{0, 0, 0};
      gbl_panel_10.rowHeights = new int[]{0, 0, 0};
      gbl_panel_10.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
      gbl_panel_10.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
      panel_10.setLayout(gbl_panel_10);
      
      JLabel lblNewLabel_8 = new JLabel("성격적 특성");
      GridBagConstraints gbc_lblNewLabel_8 = new GridBagConstraints();
      gbc_lblNewLabel_8.anchor = GridBagConstraints.EAST;
      gbc_lblNewLabel_8.insets = new Insets(0, 0, 5, 5);
      gbc_lblNewLabel_8.gridx = 0;
      gbc_lblNewLabel_8.gridy = 0;
      panel_10.add(lblNewLabel_8, gbc_lblNewLabel_8);
      
      typeTextField = new JTextField();
      GridBagConstraints gbc_typeTextField = new GridBagConstraints();
      gbc_typeTextField.insets = new Insets(0, 0, 5, 0);
      gbc_typeTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_typeTextField.gridx = 1;
      gbc_typeTextField.gridy = 0;
      panel_10.add(typeTextField, gbc_typeTextField);
      typeTextField.setColumns(10);  
      
      JCheckBox typeCheckBox = new JCheckBox("");
      GridBagConstraints gbc_typeCheckBox = new GridBagConstraints();
      gbc_typeCheckBox.insets = new Insets(0, 0, 5, 0);
      gbc_typeCheckBox.gridx = 2;
      gbc_typeCheckBox.gridy = 0;
      panel_10.add(typeCheckBox, gbc_typeCheckBox);   
      typeCheckBox.addItemListener(new ItemListener() {
	     public void itemStateChanged(ItemEvent arg0) {
			if(!checkboxState[11]) {
				checkboxState[11] = true;
			}
			else checkboxState[11] = false;
			
			panel_12.removeAll();
			createCharacterlist();
			}
	 	 });
      
      JLabel lblNewLabel_9 = new JLabel("버릇 / 습관");
      GridBagConstraints gbc_lblNewLabel_9 = new GridBagConstraints();
      gbc_lblNewLabel_9.anchor = GridBagConstraints.EAST;
      gbc_lblNewLabel_9.insets = new Insets(0, 0, 0, 5);
      gbc_lblNewLabel_9.gridx = 0;
      gbc_lblNewLabel_9.gridy = 1;
      panel_10.add(lblNewLabel_9, gbc_lblNewLabel_9);
      
      habitTextField = new JTextField();
      GridBagConstraints gbc_habitTextField = new GridBagConstraints();
      gbc_habitTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_habitTextField.gridx = 1;
      gbc_habitTextField.gridy = 1;
      panel_10.add(habitTextField, gbc_habitTextField);
      habitTextField.setColumns(10);
      
      JCheckBox habitCheckBox = new JCheckBox("");
      GridBagConstraints gbc_habitCheckBox = new GridBagConstraints();
      gbc_habitCheckBox.insets = new Insets(0, 0, 5, 0);
      gbc_habitCheckBox.gridx = 2;
      gbc_habitCheckBox.gridy = 1;
      panel_10.add(habitCheckBox, gbc_habitCheckBox);   
      habitCheckBox.addItemListener(new ItemListener() {
	     public void itemStateChanged(ItemEvent arg0) {
			if(!checkboxState[12]) {
				checkboxState[12] = true;
			}
			else checkboxState[12] = false;
			
			panel_12.removeAll();
			createCharacterlist();
			}
	 	 });
      
      JPanel new_type_panel = new JPanel();
      panel_5.add(new_type_panel, BorderLayout.CENTER);
      new_type_panel.setLayout(new BorderLayout(0, 0));
      
      JPanel panel_23 = new JPanel();
      panel_23.setBorder(new TitledBorder(null, "인물 관계", TitledBorder.LEADING, TitledBorder.TOP, null, null));
      new_type_panel.add(panel_23);
      GridBagLayout gbl_panel_23 = new GridBagLayout();
      gbl_panel_23.columnWidths = new int[]{0, 0, 0};
      gbl_panel_23.rowHeights = new int[]{0, 0, 0};
      gbl_panel_23.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
      gbl_panel_23.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
      panel_23.setLayout(gbl_panel_23);

      JLabel lblNewLabel_28 = new JLabel("관계");
      GridBagConstraints gbc_lblNewLabel_28 = new GridBagConstraints();
      gbc_lblNewLabel_28.anchor = GridBagConstraints.EAST;
      gbc_lblNewLabel_28.insets = new Insets(0, 0, 5, 5);
      gbc_lblNewLabel_28.gridx = 0;
      gbc_lblNewLabel_28.gridy = 0;
      panel_23.add(lblNewLabel_28, gbc_lblNewLabel_28);
      
      relationTextField = new JTextField();
      GridBagConstraints gbc_relationTextField = new GridBagConstraints();
      gbc_relationTextField.insets = new Insets(0, 0, 5, 0);
      gbc_relationTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_relationTextField.gridx = 1;
      gbc_relationTextField.gridy = 0;
      panel_23.add(relationTextField, gbc_relationTextField);
      relationTextField.setColumns(10);
      
      JCheckBox relationCheckBox = new JCheckBox("");
      GridBagConstraints gbc_relationCheckBox = new GridBagConstraints();
      gbc_relationCheckBox.insets = new Insets(0, 0, 5, 0);
      gbc_relationCheckBox.gridx = 2;
      gbc_relationCheckBox.gridy = 0;
      panel_23.add(relationCheckBox, gbc_relationCheckBox);
      
      relationCheckBox.addItemListener(new ItemListener() {
    	  public void itemStateChanged(ItemEvent arg0) {
    			if(!checkboxState[13]) {
    				checkboxState[13] = true;
    			}
    			else checkboxState[13] = false;
    			
    			panel_12.removeAll();
    			createCharacterlist();
    		}
    	  });
      
      JLabel lblNewLabel_29 = new JLabel("타겟");
      GridBagConstraints gbc_lblNewLabel_29 = new GridBagConstraints();
      gbc_lblNewLabel_29.anchor = GridBagConstraints.EAST;
      gbc_lblNewLabel_29.insets = new Insets(0, 0, 0, 5);
      gbc_lblNewLabel_29.gridx = 0;
      gbc_lblNewLabel_29.gridy = 1;
      panel_23.add(lblNewLabel_29, gbc_lblNewLabel_29);
      
      targetTextField = new JTextField();
      GridBagConstraints gbc_targetTextField = new GridBagConstraints();
      gbc_targetTextField.fill = GridBagConstraints.HORIZONTAL;
      gbc_targetTextField.gridx = 1;
      gbc_targetTextField.gridy = 1;
      panel_23.add(targetTextField, gbc_targetTextField);
      targetTextField.setColumns(10);
      
      JCheckBox targetCheckBox = new JCheckBox("");
      GridBagConstraints gbc_targetCheckBox = new GridBagConstraints();
      gbc_targetCheckBox.insets = new Insets(0, 0, 5, 0);
      gbc_targetCheckBox.gridx = 2;
      gbc_targetCheckBox.gridy = 1;
      panel_23.add(targetCheckBox, gbc_targetCheckBox);
      
      targetCheckBox.addItemListener(new ItemListener() {
    	  public void itemStateChanged(ItemEvent arg0) {
    			if(!checkboxState[14]) {
    				checkboxState[14] = true;
    			}
    			else checkboxState[14] = false;
    			
    			panel_12.removeAll();
    			createCharacterlist();
    		}
    	  });
      
      //////////////////////////////////////////////////////////////////
      JPanel panel_btn = new JPanel();
      panel_5.add(panel_btn, BorderLayout.SOUTH);
      panel_btn.setLayout(new BorderLayout(0, 0));
      
      JPanel new_panel_btn = new JPanel();
      new_panel_btn.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
      panel_btn.add(new_panel_btn);
      new_panel_btn.setLayout(new GridLayout(0, 2, 0, 0));
      
    //----------------------------------------정보저장 버튼 ---------------------------------------------------
      JButton saveBtn = new JButton("정보저장");
      saveBtn.setPreferredSize(new Dimension(20, 30));
      new_panel_btn.add(saveBtn);
      saveBtn.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent arg0) {
        	  if(checkEmpty()) return;
              getTextData();
              reloadTableData();
          }
      });
      
    //----------------------------------------정보업데이트 버튼 ---------------------------------------------------
      JButton resaveBtn = new JButton("정보수정");
      resaveBtn.setPreferredSize(new Dimension(20, 30));
      new_panel_btn.add(resaveBtn);
      resaveBtn.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent arg0) {
        	  if(checkEmpty()) return;
              resaveTextData();
              reloadTableData();
          }
      });
      
    //----------------------------------------정보초기화 버튼 ---------------------------------------------------
      
      JButton clearBtn = new JButton("초기화");
      clearBtn.setPreferredSize(new Dimension(20, 30));
      new_panel_btn.add(clearBtn);
      clearBtn.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent arg0) {
              System.out.println("clear");
              clearTextData();
          }
      });
      
    //----------------------------------------정보삭제 버튼 ---------------------------------------------------
      JButton removeBtn = new JButton("삭제");
      removeBtn.setPreferredSize(new Dimension(20, 30));
      new_panel_btn.add(removeBtn);
      removeBtn.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent arg0) {
        	 if(checkEmpty()) return;
             System.out.println("remove");
             removeTextData();
             reloadTableData();
         }
      });
      
      createCharacterlist();
      
      
      //////////////////////////////////////////////////////////////////
     //----------------------------------------캐릭터 정보 불러오기 버튼 ---------------------------------------------------
  
       
//      JPanel panel_13 = new JPanel();
//      splitPane_4.setRightComponent(panel_13);
      
      JPanel pan_tab_seq = new JPanel();
      tabbedPane.addTab("시퀀스", null, pan_tab_seq, null);
      pan_tab_seq.setLayout(new BorderLayout(0, 0));
      
      JPanel panel_11 = new JPanel();
      pan_tab_seq.add(panel_11);
      
      
      
      
      
      
 ///////////////////////////////////////////////관계형성 
		JPanel pan_tab_relation = new JPanel();
		tabbedPane.addTab("관계 형성", pan_tab_relation);

		// ------------------------------------------------------------------------------------------------
		pan_tab_relation.setLayout(new GridLayout(2, 0));
		pan_tab_relation
				.setBorder(new TitledBorder(null, "캐릭터 정보 리스트", TitledBorder.LEADING, TitledBorder.TOP, null, null));

		ArrayList<String> checkboxArray = new ArrayList<String>();
		for (int i = 0; i < checkboxState.length; i++) {
			if (checkboxState[i])
				checkboxArray.add(checkboxString[i]);
		}

		String[] header = new String[checkboxArray.size()];
		for (int i = 0; i < checkboxArray.size(); i++) {
			header[i] = checkboxArray.get(i);
		}

		model = new DefaultTableModel(null, header) {
			// 테이블 수정 못하게 하기
			@Override
			public boolean isCellEditable(int row, int column) {
				if (column >= 0) {
					return false;
				} else {
					return true;
				}
			}
		};

		table = new JTable(model);
		scroll = new JScrollPane(table);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		pan_tab_relation.add("North", scroll);
		// panel_12.add(table);
		loadFirstTable(); // DB데이터 첫 호출 -> 테이블에 뿌려줌
		
		JPanel jp = new JPanel();
		pan_tab_relation.add("South", jp);

		JButton visual = new JButton("시각화");
		jp.add(visual);
		visual.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				JButton b = (JButton) arg0.getSource();
				if(b.getText().equals("시각화")){
////////////////////////////////////////////////////////
					//이부분에 GraphBasic.class가 작동할 수 있도록 집어 넣으면 된다!
					
					try
					{
						UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
					}
					catch (Exception e1)
					{
						e1.printStackTrace();
					}

					mxSwingConstants.SHADOW_COLOR = Color.LIGHT_GRAY;
					mxConstants.W3C_SHADOWCOLOR = "#D3D3D3";
					
					GraphEditor editor = new GraphEditor();
					editor.createFrame(new EditorMenuBar(editor)).setVisible(true);
					Map<String, String> text;
					try {
						text = mxPngTextDecoder.decodeCompressedText(new FileInputStream(new File("D:/heechul/eclipse_luna/workspace/Visualization_total/jHanNanum-0.8.4/지하국대적퇴치설화_개체재구성_1.png")));
						if (text != null)
						{
							String value = text.get("mxGraphModel");

							if (value != null)
							{
								Document document;
								try {
									document = mxXmlUtils.parseXml(URLDecoder.decode(value, "UTF-8"));
									mxCodec codec = new mxCodec(document);
									codec.decode(document.getDocumentElement(), editor.getGraphComponent().getGraph().getModel());
								} catch (UnsupportedEncodingException e) {
									e.printStackTrace();
								}
								editor.setCurrentFile(new File("D:/heechul/eclipse_luna/workspace/Visualization_total/jHanNanum-0.8.4/지하국대적퇴치설화_개체재구성_1.png"));
								editor.setModified(false);
								editor.getUndoManager().clear();
								editor.getGraphComponent().zoomAndCenter();
								return;
							}
						}
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}					

					JOptionPane.showMessageDialog(editor, mxResources.get("imageContainsNoDiagramData"));
					
					
///////////////////////////////////////////////////////					
				}
				else System.out.println("시각화아니지롱");
				
			}
			
		});
		
      //------------------------------------------------------------------------------------------------      
    }

   @Override
   public void actionPerformed(ActionEvent e) {
      // TODO Auto-generated method stub
      if(e.getSource() == btn_loadfile){
         FileDialog open_dial = new FileDialog(frame,"열기", FileDialog.LOAD);
         open_dial.setFile("*.txt");
         open_dial.setVisible(true);
         txt_filepath.setText(open_dial.getDirectory()+open_dial.getFile());
         open_file_path = new File(open_dial.getDirectory()+open_dial.getFile());
         read_file();

      }
   }
   
   public void DspFileList(){
//      dmFileList.addElement("test");
//      dmFileList.addElement("test");
//      dmFileList.addElement("test");
//      dmFileList.addElement("test");
//      lst_select_noun.setModel(dmFileList);
   }
   
   public void read_file(){
      BufferedReader in = null;   
      try{
         in = new BufferedReader(new InputStreamReader(new FileInputStream(open_file_path), "UTF-8"));
         String s = null;
         
         while((s = in.readLine()) != null){
            //System.out.println(s);
            dmFileList.addElement(s.toString());
         }
         lst_select_noun.setModel(dmFileList);
         
//         DspFileList();

      }catch(Exception e){
         e.printStackTrace();
      }finally{
         ;
         // BufferedReader FileReader를 닫아준다.
         if(in != null) try{in.close();}catch(IOException e){}
         //if(fr != null) try{fr.close();}catch(IOException e){}
      }
   }
   
   public void keyword_search(){
      
   }
   public static void main(String[] args) {
      EventQueue.invokeLater(new Runnable() {
         public void run() {
            try {
               multi window = new multi();
               window.frame.setVisible(true);
            } catch (Exception e) {
               e.printStackTrace();
            }
         }
      });
   }

   @Override
   public void mouseClicked(MouseEvent arg0) {
      // TODO Auto-generated method stub
      if(arg0.getClickCount() == 2){
         //System.out.println("double click!!");
         int pos = txtarea_editor.getCaretPosition();
         txtarea_editor.insert(lst_select_noun.getSelectedValue().toString(), pos);
         
      }
   }

   
   @Override
   public void mouseEntered(MouseEvent arg0) {
      // TODO Auto-generated method stub
      
   }

   @Override
   public void mouseExited(MouseEvent arg0) {
      // TODO Auto-generated method stub
      
   }

   @Override
   public void mousePressed(MouseEvent arg0) {
      // TODO Auto-generated method stub
      
   }

   @Override
   public void mouseReleased(MouseEvent arg0) {
      // TODO Auto-generated method stub
      
   }
   
   //----------------------------------------이미지 부분 ---------------------------------------------------
   //////////////////////////////////////////////////////////////////////////////
   private String showLoad() {
      FileDialog fDia = new FileDialog(this, "이미지 열기", FileDialog.LOAD);
      fDia.setVisible(true);
      String fName = fDia.getFile();
      String fDir = fDia.getDirectory();
      String fRoute = fDir + fName;
      return fRoute;
   }
   
   private Image showImage(String fRoute) {
      Toolkit t = Toolkit.getDefaultToolkit();
      Image btnImage = t.getImage(fRoute);
      return btnImage;
   }
   
   private void createCharacterlist() {//하단의 캐릭터 리스트 생성
	   panel_12 = new JPanel();
	   panel_12.setBorder(new TitledBorder(null, "캐릭터 정보 리스트", TitledBorder.LEADING, TitledBorder.TOP, null, null));
	   splitPane_3.setRightComponent(panel_12);
	   panel_12.setLayout(new BorderLayout(0, 0));
	   
       ArrayList<String> checkboxArray = new ArrayList<String>();
       for(int i = 0; i < checkboxState.length; i++) {
			if(checkboxState[i]) checkboxArray.add(checkboxString[i]);
		}
       
       String[] header = new String[checkboxArray.size()];
       for(int i = 0; i < checkboxArray.size(); i++) {
    	   header[i] = checkboxArray.get(i);
       } 

       //model = new DefaultTableModel(null, header);
       model = new DefaultTableModel(null, header){
    	   //테이블 수정 못하게 하기
    	    @Override
    	       public boolean isCellEditable(int row, int column){
    	    	  if(column>=0){
    	    		  return false;
    	    	  }else{
    	    		  return true;
    	    	  }
    	       }  
       };
      
//       List list = new List();
//       panel_12.add(list, BorderLayout.CENTER);
       table = new JTable(model);
       scroll = new JScrollPane(table);
       scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
       scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
       table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
       panel_12.add(scroll);
       //panel_12.add(table); 
       loadFirstTable(); // DB데이터 첫 호출 -> 테이블에 뿌려줌
       
       table.addMouseListener(new MouseAdapter() {
           public void mouseClicked(MouseEvent e) {
              if(e.getClickCount() == 2) {
             	 setTextData();
              }
           }
        });
   }
  
   private void loadFirstTable() {//테이블 데이터 첫 호출
	   String SQL = "select * from caracter order by M_Name asc";
       try {
       	 ps = conn.prepareStatement(SQL);
			 rset = ps.executeQuery();
			
			 while (rset.next()) {
				 ArrayList<String> checkboxArray = new ArrayList<String>();
			       for(int i = 0; i < checkboxState.length; i++) {
						if(checkboxState[i]) checkboxArray.add(checkboxSql[i]);
					}
			       
			       Object[] header = new Object[checkboxArray.size()];
			       String[] data = new String[checkboxArray.size()];
			       for(int i = 0; i < checkboxArray.size(); i++) {
			    	   data[i] = rset.getString(checkboxArray.get(i));
			    	   header[i] = data[i];
			       }
				
				 model.addRow(header);
			 }
		 } catch (SQLException e) {
			 e.printStackTrace();
		 }
   }
   
   private void reloadTableData() {//테이블 데이터 재 호출
	   String SQL = "select * from caracter order by M_Name asc";
       
       //clean
       model =(DefaultTableModel)table.getModel(); 
       model.setNumRows(0); //Jtable의 데이터를 0으로 초기화 시켜서 처음부터 다시 테이블을 뿌려줌
       try {
      	 ps = conn.prepareStatement(SQL);
      	 rset = ps.executeQuery();
			
			 while (rset.next()) {
				 ArrayList<String> checkboxArray = new ArrayList<String>();
			       for(int i = 0; i < checkboxState.length; i++) {
						if(checkboxState[i]) checkboxArray.add(checkboxSql[i]);
					}
			       
			       Object[] header = new Object[checkboxArray.size()];
			       String[] data = new String[checkboxArray.size()];
			       for(int i = 0; i < checkboxArray.size(); i++) {
			    	   data[i] = rset.getString(checkboxArray.get(i));
			    	   header[i] = data[i];
			       }
				
				 model.addRow(header);
			 }
		 } catch (SQLException e) {
			 e.printStackTrace();
		 }
   }
   
   private void setTextData() {// 상단에 클릭한 캐릭터 정보 호출하기
	   int row = table.getSelectedRow();
 	   int col = 0;
 	   Object value = table.getValueAt(row, col);
 	  
 	   DB2 dto = new DB2();
 	   DB1 getVo = dto.getBy_M_Name(value.toString());
 	  
 	   nameTextField.setText(getVo.get_M_Name());
	   ageTextField.setText(getVo.get_M_Age());
	   genderTextField.setText(getVo.get_M_Sex());
	   jobTextField.setText(getVo.get_M_Job());
	   birthTextField.setText(getVo.get_M_Birth());
	   growTextField.setText(getVo.get_M_Grow());
	   heightTextField.setText(getVo.get_M_Cm());
	   weightTextField.setText(getVo.get_M_Kg());
	   bodyTextField.setText(getVo.get_M_Body());
	   clothTextField.setText(getVo.get_M_Cloth());
	   itemTextField.setText(getVo.get_M_Item());
	   typeTextField.setText(getVo.get_M_Type());
	   habitTextField.setText(getVo.get_M_Habit());
	   imageRoute = getVo.get_M_Route();
	   relationTextField.setText(getVo.getRelation());
	   targetTextField.setText(getVo.getTarget());
	   
	   System.out.println(nameTextField);
	   
	   Image btnImage = showImage(imageRoute);
       btnImage = btnImage.getScaledInstance(imageBtn.getWidth(), imageBtn.getHeight(), java.awt.Image.SCALE_SMOOTH);
       ImageIcon ic = new ImageIcon(btnImage);
       imageBtn.setIcon(ic);
   }
   
   //----------------------------------------정보 저장 부분 ---------------------------------------------------
   private void getTextData() {
       String imageStr = imageRoute;
       String nameStr = nameTextField.getText();
       String ageStr = ageTextField.getText();
       String genderStr = genderTextField.getText();
       String jobStr = jobTextField.getText();
       String birthStr = birthTextField.getText();
       String growStr = growTextField.getText();
       String heightStr = heightTextField.getText();
       String weightStr = weightTextField.getText();
       String bodyStr = bodyTextField.getText();
       String clothStr = clothTextField.getText();
       String itemStr = itemTextField.getText();
       String typeStr = typeTextField.getText();
       String habitStr = habitTextField.getText();
       String relationStr = relationTextField.getText();
       String targetStr = targetTextField.getText();
       
       DB1 vo = new DB1(nameStr, ageStr, genderStr, jobStr, birthStr, growStr, heightStr, weightStr, bodyStr, clothStr, itemStr, typeStr, habitStr, imageStr, relationStr, targetStr);
       DB2 dto = new DB2();
       model.addRow(new Object[] {nameStr, genderStr, jobStr});
       if(dto.insert(vo) == -1) {		//데이터에 이름 중복시 에러 메시지 
		   JOptionPane.showMessageDialog(null, "동일한 이름이 있습니다.","정보 저장 실패",JOptionPane.PLAIN_MESSAGE);
    	   return;
       }
       else {
    	   JOptionPane.showMessageDialog(null, "정보 저장이 완료되었습니다.","정보 저장 완료",JOptionPane.PLAIN_MESSAGE);
       }
       
       complete = true;
   }
   
   //----------------------------------------정보 업데이트 부분 -----------------------------------------------
   private void resaveTextData() {
	   String imageStr = imageRoute;
	   String nameStr = nameTextField.getText();
	   String ageStr = ageTextField.getText();
	   String genderStr = genderTextField.getText();
	   String jobStr = jobTextField.getText();
	   String birthStr = birthTextField.getText();
	   String growStr = growTextField.getText();
	   String heightStr = heightTextField.getText();
	   String weightStr = weightTextField.getText();
	   String bodyStr = bodyTextField.getText();
	   String clothStr = clothTextField.getText();
	   String itemStr = itemTextField.getText();
	   String typeStr = typeTextField.getText();
	   String habitStr = habitTextField.getText();
       String relationStr = relationTextField.getText();
       String targetStr = targetTextField.getText();
	      
	   DB1 vo = new DB1(nameStr, ageStr, genderStr, jobStr, birthStr, growStr, heightStr, weightStr, bodyStr, clothStr, itemStr, typeStr, habitStr, imageStr, relationStr, targetStr);
	   DB2 dto = new DB2();
	   if(dto.update(vo)==0) {
		   JOptionPane.showMessageDialog(null, "일치하는 이름이 없습니다.","정보 수정 실패",JOptionPane.PLAIN_MESSAGE);
		   return;
	   }
	   else {
		   JOptionPane.showMessageDialog(null, "정보 수정이 완료되었습니다.","정보 수정 완료",JOptionPane.PLAIN_MESSAGE);
	   }
	   complete = true;
   }
   
   private void clearTextData() {
	  imageRoute = "";
      imageBtn.setIcon(null);
      nameTextField.setText("");
      ageTextField.setText("");
      genderTextField.setText("");
      jobTextField.setText("");
      birthTextField.setText("");
      growTextField.setText("");
      heightTextField.setText("");
      weightTextField.setText("");
      bodyTextField.setText("");
      clothTextField.setText("");
      itemTextField.setText("");
      typeTextField.setText("");
      habitTextField.setText("");
      relationTextField.setText("");
      targetTextField.setText("");
   }
  
   //----------------------------------------정보 삭제 부분 ---------------------------------------------------
   private void removeTextData() {
	   DB2 dto = new DB2();
	   if(dto.deleteName(nameTextField.getText())==0) {
           JOptionPane.showMessageDialog(null, "일치하는 이름이 없습니다.","정보 삭제 실패",JOptionPane.PLAIN_MESSAGE);
           return;
	   }
	   else {
		   JOptionPane.showMessageDialog(null, "정보 삭제가 완료되었습니다.","정보 삭제 성공",JOptionPane.PLAIN_MESSAGE);
		   clearTextData();
	   }
   }
     
   //----------------------------------------이름 공백일 경우 에러 메시지 ------------------------------------------
   private boolean checkEmpty() {
	   if(nameTextField.getText().isEmpty()) {
		   JOptionPane.showMessageDialog(null, "이름을 입력해 주세요.","정보 생성 실패",JOptionPane.PLAIN_MESSAGE);
		   return true;
	   }
	   
	   return false;
   }
   ////////////////////////////////////////////////////////////////////////////////
   
   
   //에디터부분 MyKeyListener
	int i = 0;

	class MyKeyListener extends KeyAdapter { // 스페이스 눌럿을떄의 이벤트를 하기 위한 내부클래스
		public void keyPressed(KeyEvent e) {
			int keyCode = e.getKeyCode();

			switch (keyCode) {
			case KeyEvent.VK_SPACE: // 스페이스 일 경우
				// int i=(int)(Math.random() * 3); //랜덤으로 0~3까지 i에 저장

				multi.values = tmp.get(i++); // 문자열집합이 저장된 어레이 리스트는 0~3까지
												// 정해놓았기 때문에 랜덤으로 변경됨
				multi.list.setVisible(true); // 스페이스 입력이 나타나게 함
				list.setModel(new AbstractListModel() { // 동시에 리스트 내용도 같이 변경되야하기
														// 떄문에 넣은 부분.
					public int getSize() {
						return values.length;
					}

					public Object getElementAt(int index) {
						return values[index];
					}
				});
//				pan_editor.revalidate(); // 리셋
//				pan_editor.repaint(); // 리셋2
				editor_bot.revalidate();
				editor_bot.repaint();
				break;

			case KeyEvent.VK_BACK_SPACE:// 다 지웟을경우 사라지게 하기 위한 기능.
				if (textField.getText().equals(""))
					list.setVisible(true);
//				pan_editor.revalidate();
//				pan_editor.repaint();
				editor_bot.revalidate();
				editor_bot.repaint();
				break;
			case KeyEvent.VK_DOWN:
				if (list.isVisible()) {
					list.setSelectedIndex(count);
					count++;
				}
				break;
			case KeyEvent.VK_UP:
				if (list.isVisible()) {
					count--;
					list.setSelectedIndex(count);
				}
				break;
			case KeyEvent.VK_ENTER:
				if (list.isVisible()) {
					textstring = textField.getText();
					textstring += " " + (String) list.getSelectedValue();
					textField.setText(textstring);
					textField.revalidate();
					textField.repaint();
					list.setVisible(false);
					count = 0;
				} else {
					String tmpStr = textField.getText();
					textArea.append(tmpStr + "\n\n");
					textField.setText("");
					textField.requestFocus();
					textArea.setCaretPosition(textArea.getDocument().getLength());
					count = 0;
				}
			}
		}
	}
   

	 ////////////////////////////////////////////////////
/*	   
	   class test_Frame extends JFrame implements ActionListener{
	      
	       private JFileChooser jfc = new JFileChooser();
	       private JButton jbt_open = new JButton("검사문서");
	       private JButton jbt_open2 = new JButton("비교문서");
	       private JButton jbt_start = new JButton("확인");
	       private JLabel jlb = new JLabel(" ");
	       private JLabel jlb2 = new JLabel(" ");
	       public test_Frame(){
	               super("test");
	               this.init();
	               this.start();
	               this.setSize(400,200);
	               this.setVisible(true);
	       }
	       public void init(){
	               getContentPane().setLayout(new FlowLayout());
	               add(jbt_open);
	               add(jbt_open2);
	               add(jbt_start);
	               add(jlb);
	               add(jlb2);
	       }
	       public void start(){
	               jbt_open.addActionListener(this);
	               jbt_open2.addActionListener(this);
	               jbt_start.addActionListener(this);

//	               jfc.setMultiSelectionEnabled(false);//다중 선택 불가
	       }

	       @Override
	       public void actionPerformed(ActionEvent arg0) {
	           
	    	   URI uri = null;
		   
	           if(arg0.getSource() == jbt_open){
	                   if(jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION){
	                           // showopendialog 열기 창을 열고 확인 버튼을 눌렀는지 확인
//	                           jlb.setText("검사문서 경로 : " + jfc.getSelectedFile().toString());
	                           A = jfc.getSelectedFile().toString();
	                   }
	           }else if(arg0.getSource() == jbt_open2){
	                   if(jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION){
	                           // showSaveDialog 저장 창을 열고 확인 버튼을 눌렀는지 확인
//	                           jlb2.setText("비교문서 경로 : " + jfc.getSelectedFile().toString());
	                           B = jfc.getSelectedFile().toString();
	                   }
	           }else if(arg0.getSource() == jbt_start){
	               System.out.println("A = "+A);
	               System.out.println("B = "+B);
	               try {
//					  uri = new URI("http://localhost:8090/copytest/slet004?"+A+"&"+B);
	            	   uri = new URI("http://localhost:8090/copytest/slet004");
					  System.out.println(uri);
	               } catch (URISyntaxException e) {
						e.printStackTrace();
	               }
	               dispose();
	           }
	           if(uri != null){
	        	   open(uri);
	           }
	       }
	       
	   }*/
	   ////////////////////////////////////////////////////////////////////////////////
	   // -------------표절버튼 클릭시 이벤트
	   private static void open(URI uri) {
		    if (Desktop.isDesktopSupported()) {
		      try {
		        Desktop.getDesktop().browse(uri);
		      } catch (IOException e) { /* TODO: error handling */ }
		    } else { /* TODO: error handling */ }
	   }
	   
	
   
}