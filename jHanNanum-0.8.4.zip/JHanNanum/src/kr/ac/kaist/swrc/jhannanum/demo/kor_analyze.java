package kr.ac.kaist.swrc.jhannanum.demo;

import javax.swing.JFrame;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

import javax.swing.JOptionPane;

import kr.ac.kaist.swrc.jhannanum.comm.Eojeol;
import kr.ac.kaist.swrc.jhannanum.comm.Sentence;
import kr.ac.kaist.swrc.jhannanum.hannanum.Workflow;
import kr.ac.kaist.swrc.jhannanum.hannanum.WorkflowFactory;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
//import java.awt.geom.Line2D;


import javax.swing.JTextField;
import javax.swing.JLabel;


//import java.awt.BorderLayout;
//import java.awt.Component;
import java.awt.Dimension;
//import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
//import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
//import java.io.FileReader;
import java.io.InputStreamReader;
//import java.nio.file.Files;


import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import kr.ac.kaist.swrc.jhannanum.demo.tf;

import java.awt.Color;
import java.awt.Point;

import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;




/**
 * This is a demo program of HanNanum that helps users to utilize the HanNanum library easily.
 * It uses a predefined work flow for noun extracting, which extracts only the nouns in the
 * given document. <br>
 * <br>
 * It performs noun extraction for a Korean document with the following procedure:<br>
 * 		1. Create a predefined work flow for morphological analysis, POS tagging, and noun extraction.<br>
 * 		2. Activate the work flow in multi-thread mode.<br>
 * 		3. Analyze a document that consists of several sentences.<br>
 * 		4. Print the result on the console.<br>
 * 		5. Repeats the procedure 3~4 with activated work flow.<br>
 * 		6. Close the work flow.<br>
 * 
 * @author Sangwon Park (hudoni@world.kaist.ac.kr), CILab, SWRC, KAIST
 */
@SuppressWarnings("serial")
public class kor_analyze extends JFrame{

	private JFrame frame;
	JTextArea textArea_2;
	private JTextField txtfield;
	ArrayList<String> match_term = new ArrayList<String>();
	JTextArea textArea;
	JTextArea textArea_1;
	String dir1 = "";
	String ddd = "";
	String[] tested;
	double dx = 0.0;
	double dy =0.0;
	private String texx = "";
	JPanel panel = new JPanel();
	private JTable table;
	String[] colHeaders = {"Word", "Count"};
	
	private DefaultTableModel model = new DefaultTableModel(colHeaders,0) {
		@Override public boolean isCellEditable(int row, int column){
			return false;
		}
	};
	String[][] data = {};
	String[] fi_text = {};
	String[] bad_word = {};
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		new kor_analyze();
	}

	/**
	 * Create the application.
	 */
	public kor_analyze() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		
		frame.setBounds(100, 100, 1025, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton btnOpenDialog = new JButton("Open");
		btnOpenDialog.setBounds(278, 10, 101, 37);
		
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(btnOpenDialog);
		
		JLabel lblOpenDialog = new JLabel("불러올 파일");
		lblOpenDialog.setBounds(12, 10, 70, 15);
		frame.getContentPane().add(lblOpenDialog);
		
		txtfield = new JTextField();
		txtfield.setEditable(false);
		txtfield.setEnabled(false);
		txtfield.setBounds(12, 30, 254, 16);
		frame.getContentPane().add(txtfield);
		txtfield.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("파일 내용");
		lblNewLabel.setBounds(13, 57, 57, 15);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("추출된 명사");
		lblNewLabel_1.setBounds(71, 363, 70, 15);
		frame.getContentPane().add(lblNewLabel_1);
		
		textArea_1 = new JTextArea();
		textArea_1.setEditable(false);
		textArea_1.setBounds(12, 388, 507, 141);
		textArea_1.setText("");
		frame.getContentPane().add(textArea_1);
		
		
		textArea = new JTextArea(10,30);
		textArea.setBounds(12, 80, 218, 69);
		frame.getContentPane().add(textArea);
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setBounds(12, 78, 367, 275);
		frame.getContentPane().add(scrollPane);
		JScrollPane scrollPane_1 = new JScrollPane(textArea_1);
		scrollPane_1.setBounds(12, 388, 175, 141);
		frame.getContentPane().add(scrollPane_1);
		
		JLabel lblTermFrequency = new JLabel("명사 Term Frequency");
		lblTermFrequency.setBounds(225, 363, 130, 15);
		frame.getContentPane().add(lblTermFrequency);
		
		textArea_2 = new JTextArea();
		textArea_2.setBounds(548, 53, 224, 476);
		frame.getContentPane().add(textArea_2);
		
		JScrollPane scrollPane_2 = new JScrollPane(textArea_2);
		scrollPane_2.setBounds(204, 388, 175, 141);
		frame.getContentPane().add(scrollPane_2);
		textArea_2.setText("");
		
		JLabel lblNewLabel_2 = new JLabel("최종 인물 데이터 추출");
		lblNewLabel_2.setBounds(383, 32, 130, 15);
		frame.getContentPane().add(lblNewLabel_2);
		
		
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBackground(UIManager.getColor("CheckBox.background"));
		panel.setBounds(523, 78, 474, 451);
//		panel.setAutoscrolls(rootPaneCheckingEnabled);
		panel.add(new Panneau());
		//		panel.add(new circle());
		frame.getContentPane().add(panel);
		
		
		
		
		
		
		
		
		
		frame.setVisible(true);
		
		btnOpenDialog.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				textArea_1.setText("");
				textArea_2.setText("");
				model.setNumRows(0);
//				textArea_3.setText("");
//				table.removeAll();
//				model.rowsRemoved(null);
				
				
				openFile();
			}
		});
		
		
	}
	
	public void openFile(){
		JFileChooser fileChooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter("TXT file", "txt");
		fileChooser.setFileFilter(filter);
		fileChooser.showOpenDialog(null);
		txtfield.setText(fileChooser.getSelectedFile().getAbsolutePath());
		
		dir1 = fileChooser.getSelectedFile().getAbsolutePath();
//		System.out.println(dir1);
		try
        {
			
//            FileReader reader = new FileReader(dir1);
//            BufferedReader br = new BufferedReader(reader);
			BufferedReader br = new BufferedReader(
					   new InputStreamReader(
			                      new FileInputStream(dir1), "UTF8"));
            textArea.read(br, null);                       
            br.close();
            textArea.requestFocus();
//            System.out.println(textArea.getText());
        }
        catch(Exception e2) { JOptionPane.showMessageDialog(null, e2); }
		
		NLP(textArea.getText());
	}
	
	public void NLP(String sent){
		Workflow workflow = WorkflowFactory.getPredefinedWorkflow(WorkflowFactory.WORKFLOW_NOUN_EXTRACTOR);
		
		try {
			/* Activate the work flow in the thread mode */
			workflow.activateWorkflow(true);
			
			/* Analysis using the work flow */
			String document = sent;
			workflow.analyze(document);
			
			LinkedList<Sentence> resultList = workflow.getResultOfDocument(new Sentence(0, 0, false));
			for (Sentence s : resultList) {
				Eojeol[] eojeolArray = s.getEojeols();
				for (int i = 0; i < eojeolArray.length; i++) {
					if (eojeolArray[i].length > 0) {
						String[] morphemes = eojeolArray[i].getMorphemes();
						for (int j = 0; j < morphemes.length; j++) {
//							System.out.print(morphemes[j]);
							String te = morphemes[j];
							textArea_1.append(te);;	
//							System.out.print(te + "\n");
						}
						
						textArea_1.append("\n");
					}
				}
			}
			
			
			tested = textArea_1.getText().split("\n");
			String[] sss = {};
			sss = tf.main(tested);
			
//			BufferedReader tf_br = new BufferedReader(
//					   new InputStreamReader(
//			                      new FileInputStream("C:/my.txt"), "UTF8"));
//			String[] bad = {};
//			int ssss = (int) tf_br.lines().count();
			
			Scanner s = new Scanner(new File("../jHanNanum-0.8.4/data/ex_data/my.txt"));
			ArrayList<String> list = new ArrayList<String>();
			while (s.hasNext()){
				list.add(s.next());
			}
for (int i = 0; i < sss.length; i++){
				if(sss[i] != null){
					
					
//					for (int k = 0; k < 780; k++){ 
						
//						String[] spl_text = sss[i].split("=");
//						System.out.println(tf_br.readLine());
						
//						System.out.println(tf_br.readLine());
//						System.out.println(spl_text[0]);
//						spl_ttt = spl_text[0];
//						if(spl_text[0].matches(list.get(k)) == true){
							
							textArea_2.append(sss[i] + "\n");
//							System.out.println(spl_text[0]);
											
							
//						}else {
//							System.out.println("sldkfjlskj");
//						}
//						break;
						
					
				}
					
					//					System.out.println(sss[i]);
				}
			
			bad_word = textArea_2.getText().split("\n");
			String[] tazza = {};
			Loop1 : for (int l = 0; l < bad_word.length; l++){
				tazza = bad_word[l].split("=");
				for(String string : list){
					if(string.matches(tazza[0]) == true){
						
						continue Loop1;
						
					}
					
					
				}
//				textArea_3.append(bad_word[l] + "\n");
//				fi_text[l] = bad_word[l];
				model.addRow(bad_word[l].split("="));
//				System.out.println(bad_word[l]);	
				
				
				
			}
			
//			if(bad_word != null){
//				for (int k = 0; k <bad_word.length; k++){
//					
//					
//				}
				
				table = new JTable(model);
				table.addMouseListener(new MouseAdapter(){
					public void mouseClicked(MouseEvent e){
						JTable t = (JTable)e.getSource();
						if(e.getClickCount() == 2){
							TableModel m = t.getModel();
							Point pt = e.getPoint();
							int i = t.rowAtPoint(pt);
							
							if(i >= 0){
								int row = t.convertRowIndexToModel(i);
//								System.out.println(row);
								String s = (String) m.getValueAt(row, 0);
								
//								System.out.println(s);
								texx = s;
								panel.repaint();
								match_term.clear();
//								String s = String.format("%s (%s)", m.getValueAt(row, 0), m.getValueAt(row, 1));
//								System.out.printf("%d (%d)", m.getRowCount(), m.getColumnCount());
//								JOptionPane.showMessageDialog(t, s, "title", JOptionPane.INFORMATION_MESSAGE);
							}
							
							
						}
					}
					
					
				});
				table.setBounds(385, 57, 128, 472);
				frame.getContentPane().add(table);
				JScrollPane scrollPane_3 = new JScrollPane(table);
				scrollPane_3.setBounds(386, 57, 127, 472);
				frame.getContentPane().add(scrollPane_3);
				table.updateUI();
				
//			}
			
//			}
//			System.out.println(tested);
			/* Once a work flow is activated, it can be used repeatedly. 
			document = "프로젝트 전체 회의.\n"
				+ "회의 일정은 다음과 같습니다.\n"
				+ "日時: 2010년 7월 30일 오후 1시\n"
				+ "場所: Coex Conference Room\n";
			
			workflow.analyze(document);
			
			resultList = workflow.getResultOfDocument(new Sentence(0, 0, false));
			for (Sentence s : resultList) {
				Eojeol[] eojeolArray = s.getEojeols();
				for (int i = 0; i < eojeolArray.length; i++) {
					if (eojeolArray[i].length > 0) {
						String[] morphemes = eojeolArray[i].getMorphemes();
						for (int j = 0; j < morphemes.length; j++) {
							System.out.print(morphemes[j]);
						}
						System.out.print(", ");
					}
				}
			}
			System.out.println();
			
			workflow.close();
			*/
			s.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		
		/* Shutdown the work flow */
		workflow.close();  	
		
	}
	
	public class Panneau extends JPanel {

		
        private int radius = 50;
        
		
		
        
        
//        private String[] text = {"가", "나", "3", "4", "5", "6", "7"}; 
//        private String text = "stack";

        private List<Ellipse2D> nodes;

public Panneau() {
        	
    		
            nodes = new ArrayList<>(25);
            for (int i = 0; i < 7; i++){
            	nodes.add(new Ellipse2D.Float(250 - (radius / 2), 200 - (radius / 2), radius, radius));
            }
//            nodes.add(new Ellipse2D.Float(50 - (radius / 2), 100 - (radius / 2), radius, radius));
//            nodes.add(new Ellipse2D.Float(350 - (radius / 2), 100 - (radius / 2), radius, radius));
//            nodes.add(new Ellipse2D.Float(530 - (radius / 2), 100 - (radius / 2), radius, radius));

//            addMouseListener(new MouseAdapter() {
//                @Override
//                public void mousePressed(MouseEvent e) {
//
//                    for (Ellipse2D node : nodes) {
//
//                        if (node.contains(e.getPoint())) {
//
//                            System.out.println("Clicked...");
//                            dragged = node;
//                            // Adjust for the different between the top/left corner of the
//                            // node and the point it was clicked...
//                            offset = new Point(node.getBounds().x - e.getX(), node.getBounds().y - e.getY());
////                            System.out.println(node.getBounds().x-e.getX());
//                            // Highlight the clicked node
//                            repaint();
//                            break;
//
//                        }
//
//                    }
//
//                }

//                @Override
//                public void mouseReleased(MouseEvent e) {
//                    // Erase the "click" highlight
//                    if (dragged != null) {
//                        repaint();
//                    }
//                    dragged = null;
//                    offset = null;
//                }
//            });

//            addMouseMotionListener(new MouseAdapter() {
//                @Override
//                public void mouseDragged(MouseEvent e) {
//                    if (dragged != null && offset != null) {
//                        // Adjust the position of the drag point to allow for the
//                        // click point offset
//                        Point to = e.getPoint();
//                        to.x += offset.x;
//                        to.y += offset.y;
//
//                        // Modify the position of the node...
//                        Rectangle bounds = dragged.getBounds();
//                        bounds.setLocation(to);
//                        dragged.setFrame(bounds);
//
//                        // repaint...
//                        repaint();
//                    }
//
//                }
//            });
        }
        
        
        
        @Override
        public Dimension getPreferredSize() {
            return new Dimension(470, 444);
        }
        
        ArrayList<String> list;
        
        
        @Override
        protected void paintComponent(Graphics g) {
            // declaration
//            super.paintComponent(g);
        	
            Graphics2D g2d = (Graphics2D) g.create();
            //            for (Ellipse2D node : nodes) {
//
//                g2d.setColor(Color.BLACK);
//                Point to = node.getBounds().getLocation();
//                to.x += radius / 2;
//                to.y += radius / 2;
//                if (p != null) {
//                    g2d.draw(new Line2D.Float(p, to));
//                }
//                p = to;
//
//            }
            // Draw the nodes...
            for (Ellipse2D node : nodes) {

                g2d.setColor(Color.yellow);
                g2d.fill(node);
//                if (node == dragged) {
//                    g2d.setColor(Color.BLUE);
//                    g2d.draw(node);
//                }
                g2d.setColor(Color.BLUE);
                
                FontMetrics fm = g.getFontMetrics();
//                fm.getFont().isBold();
                int textWidth = fm.stringWidth(texx);
                int x = node.getBounds().x;
                int y = node.getBounds().y;
                int width = node.getBounds().width;
                int height = node.getBounds().height;
                
                	
                	g.drawString(texx, x + ((width - textWidth)) / 2, y + ((height - fm.getHeight()) / 2) + fm.getAscent());
//                	g.drawString("aaaaaa", (int)dx, (int)dy);
                	
                
                

            }
            
            //road double_data
            
            Scanner s;
//            String comp_text = texx;
            list = new ArrayList<String>();
            
            try {
    			s = new Scanner(new File("../jHanNanum-0.8.4/data/ex_data/double_data.txt"));
    			
        		while (s.hasNext()){
        			list.add(s.next());
        			
        		}
    		} catch (FileNotFoundException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
//            System.out.println("listsize: " + list.size());
            for (int i = 0; i < list.size(); i++){
            	
            	String spt_word = list.get(i);
//                System.out.print(spt_word);
            	String[] asdf = spt_word.split(",");
//            	System.out.println(asdf[1]);
            	
            	
//            	System.out.print(spt_word[i] + "\n");
            	if(texx.contains(asdf[0]) == true){
            		
            		match_term.add(asdf[1]);
            	}
            }
            
            ArrayList< Point > pins = new ArrayList< Point >();
            setCirclePoint( pins, 232, 205, 80 );
            
//            g.fillRect( 20, 20, getWidth() - 40, getHeight() - 40 );
			g.setColor( Color.BLACK );
			
//			System.out.println(texx.length());
//			System.out.println("matchsize: " + match_term.size());
//			for(int i = 0; i <match_term.size(); i++){
//				System.out.println(match_term.get(i));
//			}
			if (match_term.size() != 0){
				int count_term = 0;
				for ( Point pin : pins )
				{
	//				System.out.println(pin);
					g.drawString(match_term.get(count_term), (int)java.lang.Math.round( pin.getX() ), (int)java.lang.Math.round( pin.getY() ));
					
	//				g.fillOval((int)java.lang.Math.round( pin.getX() ), (int)java.lang.Math.round( pin.getY() ), 20, 20 );
					count_term++;
	
				}
			}else {
				for ( Point pin : pins )
				g.drawString("text", (int)java.lang.Math.round( pin.getX() ), (int)java.lang.Math.round( pin.getY() ));
			}
			g2d.dispose();
			}
            

			
		
        }
        
        public String[] term_comp(String[] abs){
        	
        	
			return abs;
        	
        }
        
        private void setCirclePoint( ArrayList< Point > items, double CenterX, double CenterY, double Radius )
		{
        	
			for ( double i = 0; i < 3.14 * 2; i += 8.0/match_term.size() )
			{
				
				dx = CenterX + ( ( java.lang.Math.cos( i ) ) * Radius );
				dy = CenterY - ( ( java.lang.Math.sin( i ) ) * Radius );
				
				Point point = new Point();
				point.setLocation( dx, dy );
				
				
				items.add( point );
			}
		}
	
}
    
