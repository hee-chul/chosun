package kr.ac.kaist.swrc.jhannanum.demo;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;

import java.awt.Dialog.ModalExclusionType;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.Rectangle;

import javax.swing.border.TitledBorder;
import javax.swing.UIManager;
import javax.swing.JTextArea;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;

import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextPane;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JMenuItem;

import java.awt.Frame;
import java.io.File;
import java.io.IOException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ListSelectionModel;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class STS extends JFrame{
	private JTextField textField;
	private JTable table;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private BufferedImage image;
	JLabel label;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_8;
	private JTextField textField_9;
	public STS(){
		setSize(new Dimension(1024, 700));
		setPreferredSize(new Dimension(1024, 700));
		setName("frame");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Test");
		
		
		String columnNames[] =	{ "상품번호", "상품이름", "상품가격", "상품설명" };
		Object rowData[][] = {
				{1, "aa", "bb", "cc"}
		};
		
		DefaultTableModel defaultTableModel;
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("파일");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmOpen = new JMenuItem("열기");
		mnNewMenu.add(mntmOpen);
		
		JMenuItem mntmSave = new JMenuItem("저장");
		mnNewMenu.add(mntmSave);
		
		JMenuItem mntmExit = new JMenuItem("끝내기");
		mnNewMenu.add(mntmExit);
		
		JMenu menu = new JMenu("도움말");
		menuBar.add(menu);
		
		JMenuItem menuItem = new JMenuItem("프로그램 정보");
		menu.add(menuItem);
		
		JTabbedPane tabbedPane = new JTabbedPane(SwingConstants.TOP);
		getContentPane().add(tabbedPane, BorderLayout.CENTER);
		
		JPanel pan_tab1 = new JPanel();
		tabbedPane.addTab("기본 플롯 분석 및 수정", null, pan_tab1, null);
		pan_tab1.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
		
		JPanel panel = new JPanel();
		panel.setPreferredSize(new Dimension(480, 300));
		panel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		panel.setLocation(new Point(30, 50));
		panel.setBorder(new TitledBorder(null, "\uAC80\uC0C9", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		pan_tab1.add(panel);
		
		textField = new JTextField();
		textField.setColumns(35);
		
		JButton btnNewButton = new JButton("검색");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		
		table = new JTable(new DefaultTableModel(rowData, columnNames));		
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setSize(new Dimension(500, 500));
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addComponent(textField, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 151, GroupLayout.PREFERRED_SIZE)
					.addGap(5))
				.addComponent(table, GroupLayout.DEFAULT_SIZE, 468, Short.MAX_VALUE)
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton, 0, 0, Short.MAX_VALUE)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(12)
					.addComponent(table, GroupLayout.DEFAULT_SIZE, 243, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "\uD50C\uB86F", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setPreferredSize(new Dimension(500, 300));
		pan_tab1.add(panel_1);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JTextArea textArea_1 = new JTextArea();
		panel_1.add(textArea_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(null, "\uD50C\uB86F \uC218\uC815", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_2.setPreferredSize(new Dimension(980, 300));
		pan_tab1.add(panel_2);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		JTextArea textArea = new JTextArea();
		panel_2.add(textArea);
		
		JButton btnNewButton_1 = new JButton("플롯 저장");
		panel_2.add(btnNewButton_1, BorderLayout.SOUTH);
		
		JPanel pan_tab2 = new JPanel();
		tabbedPane.addTab("캐릭터 설정", null, pan_tab2, null);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new TitledBorder(null, "\uCE90\uB9AD\uD130 \uC120\uD0DD", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_3.setPreferredSize(new Dimension(100, 100));
		panel_3.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new TitledBorder(null, "\uCE90\uB9AD\uD130 \uC218\uC815", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout gl_pan_tab2 = new GroupLayout(pan_tab2);
		gl_pan_tab2.setHorizontalGroup(
			gl_pan_tab2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pan_tab2.createSequentialGroup()
					.addGap(5)
					.addComponent(panel_3, GroupLayout.PREFERRED_SIZE, 184, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel_4, GroupLayout.PREFERRED_SIZE, 804, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_pan_tab2.setVerticalGroup(
			gl_pan_tab2.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_pan_tab2.createSequentialGroup()
					.addGap(5)
					.addGroup(gl_pan_tab2.createParallelGroup(Alignment.TRAILING)
						.addComponent(panel_4, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 597, Short.MAX_VALUE)
						.addComponent(panel_3, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 597, Short.MAX_VALUE))
					.addContainerGap())
		);
		
		label = new JLabel("New label");
		label.setBorder(new LineBorder(new Color(0, 0, 0)));
		label.setBackground(Color.WHITE);
		label.setEnabled(false);
		try {                
	          image = ImageIO.read(new File("C:/Users/Public/Pictures/Sample Pictures/국화.jpg"));
	       } catch (IOException ex) {
	            // handle exception...
	       }

		textField_1 = new JTextField();
		textField_1.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("불러오기");
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		
		JButton btnNewButton_3 = new JButton("URL");
		
		JPanel panel_5 = new JPanel();
		panel_5.setBorder(new TitledBorder(null, "\uCE90\uB9AD\uD130 \uC0C1\uC138\uC815\uBCF4", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout gl_panel_4 = new GroupLayout(panel_4);
		gl_panel_4.setHorizontalGroup(
			gl_panel_4.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_4.createSequentialGroup()
					.addGroup(gl_panel_4.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_4.createSequentialGroup()
							.addGroup(gl_panel_4.createParallelGroup(Alignment.LEADING, false)
								.addComponent(textField_2)
								.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 249, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_panel_4.createParallelGroup(Alignment.LEADING)
								.addComponent(btnNewButton_3, GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
								.addComponent(btnNewButton_2, GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)))
						.addComponent(label, GroupLayout.PREFERRED_SIZE, 367, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel_5, GroupLayout.PREFERRED_SIZE, 413, GroupLayout.PREFERRED_SIZE)
					.addGap(5))
		);
		gl_panel_4.setVerticalGroup(
			gl_panel_4.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_4.createSequentialGroup()
					.addComponent(label, GroupLayout.PREFERRED_SIZE, 515, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel_4.createParallelGroup(Alignment.BASELINE)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton_2))
					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGroup(gl_panel_4.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNewButton_3)
						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
				.addComponent(panel_5, GroupLayout.DEFAULT_SIZE, 573, Short.MAX_VALUE)
		);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBorder(new TitledBorder(null, "\uAE30\uBCF8\uC0AC\uD56D \uC124\uC815", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_7 = new JPanel();
		panel_7.setBorder(new TitledBorder(null, "\uC678\uD615\uC801 \uD2B9\uC9D5", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_8 = new JPanel();
		panel_8.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		panel_8.setAlignmentX(Component.LEFT_ALIGNMENT);
		panel_8.setBorder(new TitledBorder(null, "\uB0B4\uBA74\uC801 \uD2B9\uC131", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JButton btnNewButton_4 = new JButton("초 기 화");
		
		JButton btnNewButton_5 = new JButton("저     장");
		GroupLayout gl_panel_5 = new GroupLayout(panel_5);
		gl_panel_5.setHorizontalGroup(
			gl_panel_5.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel_5.createSequentialGroup()
					.addGroup(gl_panel_5.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_panel_5.createSequentialGroup()
							.addContainerGap()
							.addComponent(btnNewButton_5))
						.addGroup(gl_panel_5.createParallelGroup(Alignment.TRAILING)
							.addGroup(gl_panel_5.createSequentialGroup()
								.addContainerGap()
								.addComponent(btnNewButton_4))
							.addGroup(gl_panel_5.createParallelGroup(Alignment.LEADING)
								.addComponent(panel_6, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 397, Short.MAX_VALUE)
								.addComponent(panel_7, GroupLayout.DEFAULT_SIZE, 397, Short.MAX_VALUE)
								.addComponent(panel_8, GroupLayout.DEFAULT_SIZE, 406, Short.MAX_VALUE))))
					.addContainerGap())
		);
		gl_panel_5.setVerticalGroup(
			gl_panel_5.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_5.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel_6, GroupLayout.PREFERRED_SIZE, 182, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(panel_7, GroupLayout.PREFERRED_SIZE, 165, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(panel_8, GroupLayout.DEFAULT_SIZE, 89, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnNewButton_4)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnNewButton_5)
					.addGap(17))
		);
		
		JLabel lblNewLabel_8 = new JLabel("성격적 특성");
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("버릇 / 습관");
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		GroupLayout gl_panel_8 = new GroupLayout(panel_8);
		gl_panel_8.setHorizontalGroup(
			gl_panel_8.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_8.createSequentialGroup()
					.addGroup(gl_panel_8.createParallelGroup(Alignment.LEADING, false)
						.addGroup(gl_panel_8.createSequentialGroup()
							.addGap(12)
							.addComponent(lblNewLabel_8)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_8, GroupLayout.PREFERRED_SIZE, 289, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_8.createSequentialGroup()
							.addContainerGap()
							.addComponent(lblNewLabel_9)
							.addGap(7)
							.addComponent(textField_9)))
					.addContainerGap(27, Short.MAX_VALUE))
		);
		gl_panel_8.setVerticalGroup(
			gl_panel_8.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_8.createSequentialGroup()
					.addGroup(gl_panel_8.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_8.createSequentialGroup()
							.addGap(8)
							.addComponent(lblNewLabel_8)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(lblNewLabel_9))
						.addGroup(gl_panel_8.createSequentialGroup()
							.addGap(5)
							.addComponent(textField_8, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(7)
							.addComponent(textField_9, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(151, Short.MAX_VALUE))
		);
		panel_8.setLayout(gl_panel_8);
		
		JLabel lblNewLabel_3 = new JLabel("키 / 몸무게");
		
		JLabel lblNewLabel_4 = new JLabel("외형적 특이점");
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("의상 / 소품");
		
		textField_11 = new JTextField();
		textField_11.setColumns(10);
		
		textField_12 = new JTextField();
		textField_12.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("/");
		
		JLabel lblNewLabel_7 = new JLabel("/");
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"162cm", "163cm"}));
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"40kg", "41kg", "42kg", "43kg", "44kg"}));
		GroupLayout gl_panel_7 = new GroupLayout(panel_7);
		gl_panel_7.setHorizontalGroup(
			gl_panel_7.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_panel_7.createSequentialGroup()
					.addComponent(lblNewLabel_3)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(comboBox_1, 0, 88, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(lblNewLabel_6)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(comboBox_2, GroupLayout.PREFERRED_SIZE, 131, GroupLayout.PREFERRED_SIZE)
					.addGap(21))
				.addGroup(gl_panel_7.createSequentialGroup()
					.addComponent(lblNewLabel_4)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField_10, GroupLayout.PREFERRED_SIZE, 283, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
				.addGroup(gl_panel_7.createSequentialGroup()
					.addComponent(lblNewLabel_5)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField_11, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(lblNewLabel_7)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(textField_12, GroupLayout.PREFERRED_SIZE, 132, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		gl_panel_7.setVerticalGroup(
			gl_panel_7.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_7.createSequentialGroup()
					.addGap(5)
					.addGroup(gl_panel_7.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_3)
						.addComponent(lblNewLabel_6)
						.addComponent(comboBox_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(comboBox_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel_7.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_4)
						.addComponent(textField_10, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel_7.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_5)
						.addComponent(textField_11, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_7)
						.addComponent(textField_12, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(37))
		);
		panel_7.setLayout(gl_panel_7);
		
		JLabel lblNewLabel = new JLabel("이    름 :");
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		
		JLabel label_1 = new JLabel("직    업 :");
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"직접입력", "무사", "임금", "공주", "도적"}));
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("성장과정");
		
		JLabel label_2 = new JLabel("나    이 :");
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("출생과정");
		GroupLayout gl_panel_6 = new GroupLayout(panel_6);
		gl_panel_6.setHorizontalGroup(
			gl_panel_6.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_6.createSequentialGroup()
					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_6.createSequentialGroup()
							.addComponent(lblNewLabel)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(label_2)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(textField_6, GroupLayout.PREFERRED_SIZE, 124, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel_6.createSequentialGroup()
							.addGroup(gl_panel_6.createSequentialGroup()
								.addComponent(label_1)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(textField_3))
							.addGap(18)
							.addComponent(comboBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
					.addGap(21))
				.addGroup(gl_panel_6.createSequentialGroup()
					.addComponent(lblNewLabel_2)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField_7)
					.addContainerGap())
				.addGroup(gl_panel_6.createSequentialGroup()
					.addComponent(lblNewLabel_1)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField_5)
					.addContainerGap())
		);
		gl_panel_6.setVerticalGroup(
			gl_panel_6.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel_6.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_6.createSequentialGroup()
							.addGap(3)
							.addComponent(lblNewLabel))
						.addGroup(gl_panel_6.createParallelGroup(Alignment.BASELINE)
							.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(label_2)
							.addComponent(textField_6, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(18)
					.addGroup(gl_panel_6.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_6.createSequentialGroup()
							.addGap(3)
							.addComponent(label_1))
						.addGroup(gl_panel_6.createParallelGroup(Alignment.BASELINE)
							.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(18)
					.addGroup(gl_panel_6.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(textField_7, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_panel_6.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(textField_5, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(56))
		);
		panel_6.setLayout(gl_panel_6);
		panel_5.setLayout(gl_panel_5);
		panel_4.setLayout(gl_panel_4);
		
		JTextPane textPane = new JTextPane();
		panel_3.add(textPane, BorderLayout.CENTER);
		pan_tab2.setLayout(gl_pan_tab2);
		
		JPanel pan_tab3 = new JPanel();
		tabbedPane.addTab("트리트먼트 작성", null, pan_tab3, null);
		
		JPanel pan_tab3_1 = new JPanel();
		pan_tab3_1.setBorder(new TitledBorder(null, "\uD50C\uB86F \uBD88\uB7EC\uC624\uAE30", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_9 = new JPanel();
		panel_9.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "\uD2B8\uB9AC\uD2B8\uBA3C\uD2B8 \uC0DD\uC131", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
		JPanel panel_10 = new JPanel();
		panel_10.setBorder(new TitledBorder(null, "\uD2B8\uB9AC\uD2B8\uBA3C\uD2B8", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JButton btn_tab3_dbsave = new JButton("최종 저장");
		GroupLayout gl_pan_tab3 = new GroupLayout(pan_tab3);
		gl_pan_tab3.setHorizontalGroup(
			gl_pan_tab3.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_pan_tab3.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_pan_tab3.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, gl_pan_tab3.createSequentialGroup()
							.addGroup(gl_pan_tab3.createParallelGroup(Alignment.TRAILING)
								.addComponent(panel_10, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 980, Short.MAX_VALUE)
								.addComponent(panel_9, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(pan_tab3_1, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 980, Short.MAX_VALUE))
							.addContainerGap())
						.addGroup(Alignment.TRAILING, gl_pan_tab3.createSequentialGroup()
							.addComponent(btn_tab3_dbsave)
							.addGap(32))))
		);
		gl_pan_tab3.setVerticalGroup(
			gl_pan_tab3.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pan_tab3.createSequentialGroup()
					.addContainerGap()
					.addComponent(pan_tab3_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel_9, GroupLayout.PREFERRED_SIZE, 184, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel_10, GroupLayout.PREFERRED_SIZE, 188, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(btn_tab3_dbsave)
					.addContainerGap())
		);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		GroupLayout gl_panel_10 = new GroupLayout(panel_10);
		gl_panel_10.setHorizontalGroup(
			gl_panel_10.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_10.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane_2, GroupLayout.DEFAULT_SIZE, 944, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_panel_10.setVerticalGroup(
			gl_panel_10.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_10.createSequentialGroup()
					.addComponent(scrollPane_2, GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
					.addContainerGap())
		);
		
		JList list_2 = new JList();
		list_2.setModel(new AbstractListModel() {
			String[] values = new String[] {"옛날 아귀 귀신이라는 큰 도적이 있었다.", "그는 종종 이 세상에서 나와서 세상을 요란하게 하고 예쁜 여자를 납치해 가기도 하였다.", "어떤 때 아귀 귀신이 임금님의 세 공주를 한꺼번에 납치하여 갔다.", "임금님은 여러 신하에게 귀신 잡을 계획을 물어보았으나 신통한 계책을 말하는 사람이 없었다.", "그런데 한 사람의 무신이 나와 자신이 그일을 맡겠다고 하였다.", "\"임금님, 저의 집은 대대로 국록을 받고 있습니다.\"", "제가 생명을 바쳐 그 은혜를 갚고자 합니다."};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		scrollPane_2.setViewportView(list_2);
		panel_10.setLayout(gl_panel_10);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		
		JButton btn_tab3_addtreat = new JButton("트리트먼트 만들기");
		GroupLayout gl_panel_9 = new GroupLayout(panel_9);
		gl_panel_9.setHorizontalGroup(
			gl_panel_9.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_panel_9.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_9.createParallelGroup(Alignment.TRAILING)
						.addComponent(btn_tab3_addtreat, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 944, Short.MAX_VALUE)
						.addComponent(scrollPane_1, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 944, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_panel_9.setVerticalGroup(
			gl_panel_9.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_9.createSequentialGroup()
					.addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btn_tab3_addtreat)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		
		JTextArea textArea_2 = new JTextArea();
		textArea_2.setText("아귀라는 도적이 지하세계로 공주를 납치해 갔다.\r\n무신은 공주를 구하여 오겠다고 떠났다.");
		scrollPane_1.setViewportView(textArea_2);
		panel_9.setLayout(gl_panel_9);
		
		JButton btn_tab3_01 = new JButton("삭제");
		
		JButton btn_tab3_02 = new JButton("저장");
		
		JButton btn_tab3_03 = new JButton("트리트먼트 추가");
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_pan_tab3_1 = new GroupLayout(pan_tab3_1);
		gl_pan_tab3_1.setHorizontalGroup(
			gl_pan_tab3_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pan_tab3_1.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 810, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_pan_tab3_1.createParallelGroup(Alignment.LEADING, false)
						.addComponent(btn_tab3_03, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btn_tab3_02, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btn_tab3_01, GroupLayout.DEFAULT_SIZE, 135, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_pan_tab3_1.setVerticalGroup(
			gl_pan_tab3_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pan_tab3_1.createSequentialGroup()
					.addGroup(gl_pan_tab3_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_pan_tab3_1.createSequentialGroup()
							.addComponent(btn_tab3_01, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btn_tab3_02, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btn_tab3_03, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE))
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(22, Short.MAX_VALUE))
		);
		
		JList list = new JList();
		scrollPane.setColumnHeaderView(list);
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"1. 아귀라는 도적이 지하세계로 공주를 납치해 갔다.", "2. 무신은 공주를 구하여 오겠다고 떠났다.", "3. 산신령이 나타나서 무신을 도와준다.", "4. 무신과 하인은 공주를 구하기 위해 지하세계로 간다.", "5. 무신이 공주를 구한다.", "6. 하인들이 무신을 배반한다.", "7. 산신령의 도움을 받아 무신이 지상세계로 올라온다.", "8. 무신은 임금을 찾아 가 사실을 알린다."};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		pan_tab3_1.setLayout(gl_pan_tab3_1);
		pan_tab3.setLayout(gl_pan_tab3);
		
		JPanel pan_tab4 = new JPanel();
		tabbedPane.addTab("시각화", null, pan_tab4, null);
		
		JPanel panel_11 = new JPanel();
		panel_11.setBorder(new TitledBorder(null, "\uCE90\uB9AD\uD130 \uC120\uD0DD", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_12 = new JPanel();
		panel_12.setBorder(new LineBorder(new Color(0, 0, 0)));
		GroupLayout gl_pan_tab4 = new GroupLayout(pan_tab4);
		gl_pan_tab4.setHorizontalGroup(
			gl_pan_tab4.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pan_tab4.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel_11, GroupLayout.PREFERRED_SIZE, 169, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel_12, GroupLayout.DEFAULT_SIZE, 803, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_pan_tab4.setVerticalGroup(
			gl_pan_tab4.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pan_tab4.createSequentialGroup()
					.addGroup(gl_pan_tab4.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_pan_tab4.createSequentialGroup()
							.addGap(5)
							.addComponent(panel_11, GroupLayout.DEFAULT_SIZE, 597, Short.MAX_VALUE))
						.addGroup(gl_pan_tab4.createSequentialGroup()
							.addContainerGap()
							.addComponent(panel_12, GroupLayout.DEFAULT_SIZE, 592, Short.MAX_VALUE)))
					.addContainerGap())
		);
		panel_11.setLayout(new BorderLayout(0, 0));
		
		JList list_1 = new JList();
		list_1.setModel(new AbstractListModel() {
			String[] values = new String[] {"     1. 아귀", "     2. 무신", "     3. 공주", "     4. 산신령", "     5. 하인"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		panel_11.add(list_1, BorderLayout.CENTER);
		pan_tab4.setLayout(gl_pan_tab4);
		
		
		
	}
	
	protected void paintComponent(Graphics g){
		super.paintComponents(g);
		g.drawImage(image, 0, 0, null);
	}
	
 public static void main(String[] args){
	 new STS();
 }
}
