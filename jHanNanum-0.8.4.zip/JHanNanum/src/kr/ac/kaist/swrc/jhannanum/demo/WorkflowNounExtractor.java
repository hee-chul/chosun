/*  Copyright 2010, 2011 Semantic Web Research Center, KAIST

This file is part of JHanNanum.

JHanNanum is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

JHanNanum is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with JHanNanum.  If not, see <http://www.gnu.org/licenses/>   */

package kr.ac.kaist.swrc.jhannanum.demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;



import kr.ac.kaist.swrc.jhannanum.comm.Eojeol;
import kr.ac.kaist.swrc.jhannanum.comm.Sentence;
import kr.ac.kaist.swrc.jhannanum.hannanum.Workflow;
import kr.ac.kaist.swrc.jhannanum.hannanum.WorkflowFactory;

/**
 * This is a demo program of HanNanum that helps users to utilize the HanNanum library easily.
 * It uses a predefined work flow for noun extracting, which extracts only the nouns in the
 * given document. <br>
 * <br>
 * It performs noun extraction for a Korean document with the following procedure:<br>
 * 		1. Create a predefined work flow for morphological analysis, POS tagging, and noun extraction.<br>
 * 		2. Activate the work flow in multi-thread mode.<br>
 * 		3. Analyze a document that consists of several sentences.<br>
 * 		4. Print the result on the console.<br>
 * 		5. Repeats the procedure 3~4 with activated work flow.<br>
 * 		6. Close the work flow.<br>
 * 
 * @author Sangwon Park (hudoni@world.kaist.ac.kr), CILab, SWRC, KAIST
 */
public class WorkflowNounExtractor {

	public static void main(String[] args) {
		Workflow workflow = WorkflowFactory.getPredefinedWorkflow(WorkflowFactory.WORKFLOW_NOUN_EXTRACTOR);
		
		try {
			/* Activate the work flow in the thread mode */
			workflow.activateWorkflow(true);
			
			/* Analysis using the work flow */
			String document = "경기도 수원에서 폐지를 팔아 생계를 꾸려가는 이복순 씨(63)는 “아무리 먹고 살기 힘들어도 쉬엄쉬엄 해야지 안 그러면 관절염이 도진다”며 인도에 리어카를 세워놓고 상가 계단에 걸터앉았다. 폐지 가격이 최근 한두 달 새 40원가량 뚝 떨어진 것이 이씨의 가장 큰 고민이다. 하루 꼬박 걸려 폐지를 주워도 손에 쥐는 돈은 고작 2000원. 일 년 전만 해도 ㎏당 170원이어서 5000원을 버는 날도 있었는데 이젠 꿈도 못 꾸는 액수다. 일찌감치 출가한 자녀들은 용돈이나 조금씩 부쳐줄 뿐이다. “이렇게 벌어서 돈이 되겠어? 그건 진작에 포기했고 그냥 박스나 끼고 살다 가는 거지….” 이씨처럼 “과연 내가 잘살 수 있겠느냐”며 미래를 비관하는 사람이 늘고 있다. 스스로 중산층이라고 생각하는 사람이 줄어들고 있지만 실제 중산층도 감소하는 추세다. 통계청 가계동향조사에 따르면 1990년 75.4%였던 중산층의 비중은 2000년 71.7%, 2005년 69.2%에서 2010년에는 67.5%로 꾸준히 줄어들고 있다. 통계청 조사기준으로 중산층은 중위소득(총 가구의 소득순위 중 가운데를 차지하는 가구의 소득)의 50~150%에 해당하는 가구다. 반면 저소득층은 1990년 7.1%에서 해마다 늘어 2010년엔 12.5%가 됐다. 고소득층이 같은 기간 17.5%에서 20.0%로 2.5%포인트 늘어난 것과 비교하면 저소득층의 증가폭이 훨씬 크다. 중산층이 줄어들고 저소득층이 늘어나는 것은 빈곤 탈출률의 감소와도 연결된다. 빈곤 탈출률은 이전 연도에는 빈곤층이었지만 다음 연도에 벗어난 가구의 비율을 의미한다. 한국보건사회연구원의 조사에 따르면 2000년 이후 도시근로자 가구의 빈곤 탈출률은 지속적으로 감소하는 양상을 보였다. 2000년에 빈곤층을 벗어나는 비율은 48.9%였지만 해마다 줄어 2005년 31.9%, 2007년엔 29.0%까지 떨어졌다. 사회적 계층 이동을 가능케 하는 교육의 양극화도 심해지고 있다. 통계청에 따르면 지난해 5분위(상위 20%) 소득계층의 월평균 교육비 지출은 56만1400원으로 1분위(하위 20%) 9만1400원의 6.14배에 달했다. 지난해 사회조사 결과에 따르면 부모 모두 대학을 나오지 않은 자녀의 첫 월급은 156만4488만원으로 부모 모두 대학을 졸업한 경우(평균 202만9009원)의 77%에 그쳤다. 강신욱 한국보건사회연구원 사회보장연구실장은 “외환위기 직후인 1998년에서 2002년 사이에만 잠시 계층변동비율이 늘었다가 그 뒤로는 계속 감소하고 있다”며 “빈곤층에서 탈출하기가 점점 더 어려워지고 중산층도 줄어드는 현상이 동시에 벌어지는 상황”이라고 말했다.\n";
			workflow.analyze(document);
			
			LinkedList<Sentence> resultList = workflow.getResultOfDocument(new Sentence(0, 0, false));
			for (Sentence s : resultList) {
				Eojeol[] eojeolArray = s.getEojeols();
				for (int i = 0; i < eojeolArray.length; i++) {
					if (eojeolArray[i].length > 0) {
						String[] morphemes = eojeolArray[i].getMorphemes();
						for (int j = 0; j < morphemes.length; j++) {
							System.out.print(morphemes[j]);
						}
						System.out.print("\n ");
					}
				}
			}
			
			/* Once a work flow is activated, it can be used repeatedly. 
			document = "프로젝트 전체 회의.\n"
				+ "회의 일정은 다음과 같습니다.\n"
				+ "日時: 2010년 7월 30일 오후 1시\n"
				+ "場所: Coex Conference Room\n";
			
			workflow.analyze(document);
			
			resultList = workflow.getResultOfDocument(new Sentence(0, 0, false));
			for (Sentence s : resultList) {
				Eojeol[] eojeolArray = s.getEojeols();
				for (int i = 0; i < eojeolArray.length; i++) {
					if (eojeolArray[i].length > 0) {
						String[] morphemes = eojeolArray[i].getMorphemes();
						for (int j = 0; j < morphemes.length; j++) {
							System.out.print(morphemes[j]);
						}
						System.out.print(", ");
					}
				}
			}
			System.out.println();
			
			workflow.close();
			*/
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		
		/* Shutdown the work flow */
		workflow.close();  	
		new WorkflowNounExtractor();
	}
	
    public WorkflowNounExtractor() {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                    ex.printStackTrace();
                }

                JFrame frame = new JFrame("Testing");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.add(new Panneau());
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            }
        });
    }

    public class Panneau extends JPanel {

        private int radius = 50;
        private String text = "stack";

        private List<Ellipse2D> nodes;

        private Ellipse2D dragged;
        private Point offset;

        public Panneau() {
            nodes = new ArrayList<>(25);

            nodes.add(new Ellipse2D.Float(50 - (radius / 2), 100 - (radius / 2), radius, radius));
            nodes.add(new Ellipse2D.Float(350 - (radius / 2), 100 - (radius / 2), radius, radius));
            nodes.add(new Ellipse2D.Float(530 - (radius / 2), 100 - (radius / 2), radius, radius));

            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {

                    for (Ellipse2D node : nodes) {

                        if (node.contains(e.getPoint())) {

                            System.out.println("Clicked...");
                            dragged = node;
                            // Adjust for the different between the top/left corner of the
                            // node and the point it was clicked...
                            offset = new Point(node.getBounds().x - e.getX(), node.getBounds().y - e.getY());
                            // Highlight the clicked node
                            repaint();
                            break;

                        }

                    }

                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    // Erase the "click" highlight
                    if (dragged != null) {
                        repaint();
                    }
                    dragged = null;
                    offset = null;
                }
            });

            addMouseMotionListener(new MouseAdapter() {
                @Override
                public void mouseDragged(MouseEvent e) {
                    if (dragged != null && offset != null) {
                        // Adjust the position of the drag point to allow for the
                        // click point offset
                        Point to = e.getPoint();
                        to.x += offset.x;
                        to.y += offset.y;

                        // Modify the position of the node...
                        Rectangle bounds = dragged.getBounds();
                        bounds.setLocation(to);
                        dragged.setFrame(bounds);

                        // repaint...
                        repaint();
                    }

                }
            });
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(400, 400);
        }

        @Override
        protected void paintComponent(Graphics g) {
            // declaration
            super.paintComponent(g);

            Graphics2D g2d = (Graphics2D) g.create();
            // Draw the connecting lines first
            // This ensures that the lines are under the nodes...
            Point p = null;
            for (Ellipse2D node : nodes) {

                g2d.setColor(Color.BLACK);
                Point to = node.getBounds().getLocation();
                to.x += radius / 2;
                to.y += radius / 2;
                if (p != null) {
                    g2d.draw(new Line2D.Float(p, to));
                }
                p = to;

            }
            // Draw the nodes...
            for (Ellipse2D node : nodes) {

                g2d.setColor(Color.yellow);
                g2d.fill(node);
                if (node == dragged) {
                    g2d.setColor(Color.BLUE);
                    g2d.draw(node);
                }
                g2d.setColor(Color.BLUE);

                FontMetrics fm = g.getFontMetrics();
                int textWidth = fm.stringWidth(text);
                int x = node.getBounds().x;
                int y = node.getBounds().y;
                int width = node.getBounds().width;
                int height = node.getBounds().height;
                g.drawString(text,
                                x + ((width - textWidth)) / 2,
                                y + ((height - fm.getHeight()) / 2) + fm.getAscent());

            }

            g2d.dispose();

        }

    }
}