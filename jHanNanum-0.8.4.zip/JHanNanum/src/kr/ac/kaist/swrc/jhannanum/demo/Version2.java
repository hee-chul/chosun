package kr.ac.kaist.swrc.jhannanum.demo;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JTextPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.DropMode;
import javax.swing.JEditorPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.JList;
import javax.swing.AbstractListModel;

public class Version2 extends JFrame {

	private JPanel contentPane;
	
	private JPanel upperPane;
	
	private JTextField textField;
	public static JList list;
	static String[] values= {};
	ArrayList<String[]> tmp = new ArrayList<String[]>();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Version2 frame = new Version2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Version2() {
		//어레이 리스트를 사용하여 문자열 집합을 저장
		tmp.add(new String[] {"아귀", "어느", "옛적", "사람", "고을", "이야기", "우리", "꿈은", "어떤", "옛날"});
		tmp.add(new String[] {"귀신", "고을", "사람", "공주","왕자","거지","도적", "산골에", "마을에", "왕"});
		tmp.add(new String[] {"큰", "아름다운", "예쁜", "못생긴","작은","귀여운","어린", "잘생긴", "욕심", "잔인한"});
		tmp.add(new String[] {"도적", "공주", "왕자", "노인","산신령","호랑이","토끼", "거북이", "거지", "신하"});
				
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField(100);
		textField.setBounds(70, 108, 300, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		textField.addKeyListener(new MyKeyListener()); //텍스트필드에 텍스트 입력이 발생하는 이벤트 장착
		
		list = new JList(); //텍스트입력시 아래 뜨게 만드는것은 J리스트를 사용하였음.
		list.setModel(new AbstractListModel() { //리스트에 들어갈 변수집합을 설정
			public int getSize() {
				return values.length; //리스트 크기 반환
			}
			public Object getElementAt(int index) {
				return values[index];//리스트에 내용접근시 필요한 index 정보 선정
			}
		});
		list.setBounds(150, 125, 116, 99);
		contentPane.add(list);
		list.setVisible(false); //우선 안보이게 하기 위해 리스트를 기본적으로 false시켜놓음
	}
	int i = 0;
	class MyKeyListener extends KeyAdapter { //스페이스 눌럿을떄의 이벤트를 하기 위한 내부클래스
        public void keyPressed(KeyEvent e) {
            int keyCode = e.getKeyCode();
            
            switch (keyCode) {
            case KeyEvent.VK_SPACE: //스페이스 일 경우
//               int i=(int)(Math.random() * 3); //랜덤으로 0~3까지 i에 저장
            	
               Version2.values=tmp.get(i++); //문자열집합이 저장된 어레이 리스트는 0~3까지 정해놓았기 때문에 랜덤으로 변경됨
               Version2.list.setVisible(true); //스페이스 입력이 나타나게 함
               list.setModel(new AbstractListModel() { //동시에 리스트 내용도 같이 변경되야하기 떄문에 넣은 부분.
       			public int getSize() {
       				return values.length;
       			}
       			public Object getElementAt(int index) {
       				return values[index];
       			}
       		});
               contentPane.revalidate(); //리셋
               contentPane.repaint(); //리셋2
                break;
            
        case KeyEvent.VK_BACK_SPACE://다 지웟을경우 사라지게 하기 위한 기능.
        	  if(textField.getText().equals(""))
              	list.setVisible(false);
            contentPane.revalidate();
            contentPane.repaint();
             break;
         }
        }
	}
}
