package kr.ac.kaist.swrc.jhannanum.demo;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

public class DB2 {			// 디비 연결 부분
	private Connection conn;
	private ResultSet rset;
	private PreparedStatement ps;

	public DB2()
	{
		try { 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "project", "0412");
			System.out.println("DB2 성공적으로 로딩완료");
			
		} catch (ClassNotFoundException e) {
			// TODO: handle exception
			System.out.println("해당 드라이버를 찾을 수 없습니다.\n" + e);
		} catch (SQLException e) {
			// TODO: handle exception
			System.out.println("해당 드라이버를 찾을 수 없습니다.\n" + e);
		}
	}
	//디비 데이터를 불러오는 메소드
	public ArrayList<DB1> getList()
	{
		ArrayList<DB1> list = new ArrayList<DB1>();
		
		String SQL = "select * from caracter order by M_Name asc";
		try{
			ps = conn.prepareStatement(SQL);
			rset = ps.executeQuery();
			
			while(rset.next()){
				String M_Name = rset.getString("M_Name");
				String M_Age = rset.getString("M_Age");
				String M_Sex = rset.getString("M_Sex");
				String M_Job = rset.getString("M_Job");
				String M_Birth = rset.getString("M_Birth");
				String M_Grow = rset.getString("M_Grow");
				String M_Cm = rset.getString("M_Cm");
				String M_Kg = rset.getString("M_Kg");
				String M_Body = rset.getString("M_Body");
				String M_Cloth = rset.getString("M_Cloth");
				String M_Item = rset.getString("M_Item");
				String M_Type = rset.getString("M_Type");
				String M_Habit = rset.getString("M_Habit");
				String M_Route = rset.getString("M_Route");
				String Relation = rset.getString("Relation");
				String Target = rset.getString("Target");
				list.add(new DB1(M_Name,M_Age,M_Sex,M_Job,M_Birth,M_Grow,M_Cm,M_Kg,M_Body,M_Cloth,M_Item,M_Type,M_Habit,M_Route,Relation,Target));
			}
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}
//삽입
	public int insert(DB1 vo)
	{
		String SQL = "insert into caracter values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		int cnt = -1;
		try{
			ps=conn.prepareStatement(SQL);
			ps.setString(1, vo.get_M_Name());
			ps.setString(2, vo.get_M_Age());
			ps.setString(3, vo.get_M_Sex());
			ps.setString(4, vo.get_M_Job());
			ps.setString(5, vo.get_M_Birth());
			ps.setString(6, vo.get_M_Grow());
			ps.setString(7, vo.get_M_Cm());
			ps.setString(8, vo.get_M_Kg());
			ps.setString(9, vo.get_M_Body());
			ps.setString(10, vo.get_M_Cloth());
			ps.setString(11, vo.get_M_Item());
			ps.setString(12, vo.get_M_Type());
			ps.setString(13, vo.get_M_Habit());
			ps.setString(14, vo.get_M_Route());
			ps.setString(15, vo.getRelation());
			ps.setString(16, vo.getTarget());
			cnt = ps.executeUpdate();
		
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;
	}
	//삭제
	public int deleteName(String M_Name)
	{
		String SQL = "delete from caracter where M_Name=?";
		int cnt=-1;
		try{
			ps = conn.prepareStatement(SQL);
			ps.setString(1,M_Name);
			cnt = ps.executeUpdate();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;
	}
	
	//수정
	public int update(DB1 vo)
	{
		String SQL= "update caracter set M_Age=?, M_Sex=?, M_Job=?, M_Birth=?, M_Grow=?, M_Cm=?, M_Kg=?, M_Body=?, M_Cloth=?, M_Item=?, M_Type=?, M_Habit=?, M_Route=?, Relation=?, Target=? where M_Name=?";
		int cnt=-1;
		try{
			ps = conn.prepareStatement(SQL);
			ps.setString(1, vo.get_M_Age());
			ps.setString(2, vo.get_M_Sex());
			ps.setString(3, vo.get_M_Job());
			ps.setString(4, vo.get_M_Birth());
			ps.setString(5, vo.get_M_Grow());
			ps.setString(6, vo.get_M_Cm());
			ps.setString(7, vo.get_M_Kg());
			ps.setString(8, vo.get_M_Body());
			ps.setString(9, vo.get_M_Cloth());
			ps.setString(10, vo.get_M_Item());
			ps.setString(11, vo.get_M_Type());
			ps.setString(12, vo.get_M_Habit());
			ps.setString(13, vo.get_M_Route());
			ps.setString(14, vo.getRelation());
			ps.setString(15, vo.getTarget());
			ps.setString(16, vo.get_M_Name());
	
			cnt = ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;
	}
	//검색 
	public int select(DB1 vo)
	{
		String SQL= "select * from caracter order by M_Name asc";
		
		int cnt=-1;
		try{
		
			cnt = ps.executeUpdate();
			ps = conn.prepareStatement(SQL);
			ps.setString(1, vo.get_M_Age());
			ps.setString(2, vo.get_M_Sex());
			ps.setString(3, vo.get_M_Job());
			ps.setString(4, vo.get_M_Birth());
			ps.setString(5, vo.get_M_Grow());
			ps.setString(6, vo.get_M_Cm());
			ps.setString(7, vo.get_M_Kg());
			ps.setString(8, vo.get_M_Body());
			ps.setString(9, vo.get_M_Cloth());
			ps.setString(10, vo.get_M_Item());
			ps.setString(11, vo.get_M_Type());
			ps.setString(12, vo.get_M_Habit());
			ps.setString(13, vo.get_M_Route());
			ps.setString(14, vo.getRelation());
			ps.setString(15, vo.getTarget());
			ps.setString(16, vo.get_M_Name());

			 ps.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;
	}

	public DB1 getBy_M_Name(String M_Name)
	{
		DB1 vo = null;
		String SQL = "select * from caracter where M_Name=?";
		
		try{
			ps = conn.prepareStatement(SQL);
			ps.setString(1, M_Name);
			rset = ps.executeQuery();
			
			rset.next();
			String M_Age = rset.getString("M_Age");
			String M_Sex = rset.getString("M_Sex");
			String M_Job = rset.getString("M_Job");
			String M_Birth = rset.getString("M_Birth");
			String M_Grow = rset.getString("M_Grow");
			String M_Cm = rset.getString("M_Cm");
			String M_Kg = rset.getString("M_Kg");
			String M_Body = rset.getString("M_Body");
			String M_Cloth = rset.getString("M_Cloth");
			String M_Item = rset.getString("M_Item");
			String M_Type = rset.getString("M_Type");
			String M_Habit = rset.getString("M_Habit");
			String M_Route = rset.getString("M_Route");
			String Relation = rset.getString("Relation");
			String Target = rset.getString("Target");
			vo = new DB1(M_Name,M_Age,M_Sex,M_Job,M_Birth,M_Grow,M_Cm,M_Kg,M_Body,M_Cloth,M_Item,M_Type,M_Habit,M_Route,Relation,Target);
			
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vo;
	}
}
	