package kr.ac.kaist.swrc.jhannanum.demo;

import java.awt.Button;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.AbstractListModel;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Test2 extends JFrame implements ActionListener{
	
	private JPanel jPanel1;
	private JPanel jPanel2;
	private JPanel jPanel3;
	
	private Button btn1;
	private Button btn2;
	private Button btn3;
	
	private JTextField textField;
	private JTextArea textArea;
	
	public static JList list;
	static String[] values = {};
	ArrayList<String[]> tmp = new ArrayList<String[]>(); 

	public static void main(String[] args) {
		new Test2();
	}
	
	public Test2(){
		
		tmp.add(new String[] {"아귀", "어느", "옛적", "사람", "고을", "이야기", "우리", "꿈은", "어떤", "옛날"});
		tmp.add(new String[] {"귀신", "고을", "사람", "공주","왕자","거지","도적", "산골에", "마을에", "왕"});
		tmp.add(new String[] {"큰", "아름다운", "예쁜", "못생긴","작은","귀여운","어린", "잘생긴", "욕심", "잔인한"});
		tmp.add(new String[] {"도적", "공주", "왕자", "노인","산신령","호랑이","토끼", "거북이", "거지", "신하"});
		
		jPanel1 = new JPanel();
//		jPanel2 = new JPanel();
//		jPanel3 = new JPanel();
		
		//textfield set
		textField = new JTextField();
		textField.setColumns(30);
		textField.setText("");
		textField.addActionListener(this);
		textField.addKeyListener(new MyKeyListener());
		
		textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setColumns(30);
		textArea.setRows(30);
		textArea.requestFocus();
		
		jPanel1.setLayout(new BoxLayout(jPanel1, BoxLayout.PAGE_AXIS));
		jPanel1.add(textArea);
		jPanel1.add(textField);
		
		list = new JList(); // 텍스트입력시 아래 뜨게 만드는것은 J리스트를 사용하였음.
		list.setModel(new AbstractListModel() { // 리스트에 들어갈 변수집합을 설정
			public int getSize() {
				return values.length; // 리스트 크기 반환
			}

			public Object getElementAt(int index) {
				return values[index];// 리스트에 내용접근시 필요한 index 정보 선정
			}
		});
		list.setBounds(150, 125, 116, 99);
		jPanel1.add(list);
		list.setVisible(false); // 우선 안보이게 하기 위해 리스트를 기본적으로 false시켜놓음
		
		
		setTitle("test");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		add(jPanel1);
		pack();
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == textField) {
			String tmpStr = textField.getText();
			textArea.append(tmpStr + "\n");
			textField.setText("");
			textField.requestFocus();
			textArea.setCaretPosition(textArea.getDocument().getLength());
		}
		
	}
	
	int i = 0;

	class MyKeyListener extends KeyAdapter { // 스페이스 눌럿을떄의 이벤트를 하기 위한 내부클래스
		public void keyPressed(KeyEvent e) {
			int keyCode = e.getKeyCode();

			switch (keyCode) {
			case KeyEvent.VK_SPACE: // 스페이스 일 경우
				// int i=(int)(Math.random() * 3); //랜덤으로 0~3까지 i에 저장

				Test2.values = tmp.get(i++); // 문자열집합이 저장된 어레이 리스트는 0~3까지
												// 정해놓았기 때문에 랜덤으로 변경됨
				Test2.list.setVisible(true); // 스페이스 입력이 나타나게 함
				list.setModel(new AbstractListModel() { // 동시에 리스트 내용도 같이 변경되야하기
														// 떄문에 넣은 부분.
					public int getSize() {
						return values.length;
					}

					public Object getElementAt(int index) {
						return values[index];
					}
				});
				jPanel1.revalidate(); // 리셋
				jPanel1.repaint(); // 리셋2
				break;

			case KeyEvent.VK_BACK_SPACE:// 다 지웟을경우 사라지게 하기 위한 기능.
				if (textField.getText().equals(""))
					list.setVisible(false);
				jPanel1.revalidate();
				jPanel1.repaint();
				break;
			}
		}
	}

}
