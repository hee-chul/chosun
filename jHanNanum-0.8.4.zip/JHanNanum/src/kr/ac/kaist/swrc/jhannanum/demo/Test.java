package kr.ac.kaist.swrc.jhannanum.demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;

public class Test extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	//버튼 추가부분
	JButton btn1 = new JButton("New button");
	JButton btn2 = new JButton("New button");
	JButton btn3 = new JButton("New button");
	JButton btn4 = new JButton("New button");
	JButton btn5 = new JButton("New button");
	JButton btn6 = new JButton("New button");
	JButton btn7 = new JButton("New button");
	JButton btn8 = new JButton("New button");
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Test frame = new Test();
					frame.setVisible(true); // 전체 프레임 실행,윈도우 빌더 프레임사용으로 인한 형태
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Test() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300); //프레임크기
		contentPane = new JPanel(); //바깥 패널생성
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER); //두번째 패널 생성
		panel.setLayout(null);
		//패널에 버튼 사이즈결정 및 추가
		btn1.setBounds(12, 60, 97, 23);
		panel.add(btn1);
		
		btn2.setBounds(114, 60, 97, 23);
		panel.add(btn2);
		
		btn3.setBounds(216, 60, 97, 23);
		panel.add(btn3);
		
		btn4.setBounds(318, 60, 97, 23);
		panel.add(btn4);
		
		btn5.setBounds(12, 88, 97, 23);
		panel.add(btn5);
		
		btn6.setBounds(114, 88, 97, 23);
		panel.add(btn6);
		
		btn7.setBounds(216, 88, 97, 23);
		panel.add(btn7);
		
		btn8.setBounds(318, 88, 97, 23);
		panel.add(btn8);
		//텍스트필드 생성 및 크기설정
		textField = new JTextField();
		textField.setBounds(151, 181, 140, 32);
		panel.add(textField);
		textField.setColumns(10);
		textField.addKeyListener(new MyKeyListener());//텍스트필드에 스페이스 입력이 이벤트 장착
	}
	public void reset() //버튼 내부의 내용을 바꾸기 위한 함수 설게
	{	//버튼들의 내용들을 랜덤함수로 임의로 바꿈
		btn1.setText((int)(Math.random() *  6) + 3+"");
		btn2.setText((int)(Math.random() *  6) + 3+"");
		btn3.setText((int)(Math.random() *  6) + 3+"");
		btn4.setText((int)(Math.random() *  6) + 3+"");
		btn5.setText((int)(Math.random() *  6) + 3+"");
		btn6.setText((int)(Math.random() *  6) + 3+"");
		btn7.setText((int)(Math.random() *  6) + 3+"");
		btn8.setText((int)(Math.random() *  6) + 3+"");
		contentPane.revalidate(); //새로고침 개념의 함수
		contentPane.repaint(); //다시 그리는 함수
	}
//내부클래스를 사용하여 키이벤트 리스너 구현
	class MyKeyListener extends KeyAdapter {
        public void keyPressed(KeyEvent e) {
            int keyCode = e.getKeyCode();
            switch (keyCode) {
            case KeyEvent.VK_SPACE://스페이스 입력할경우의 이벤트
               reset();
                break;
            }
        }
    }
}
