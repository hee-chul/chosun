package kr.ac.kaist.swrc.jhannanum.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;

import kr.ac.kaist.swrc.jhannanum.demo.kor_analyze;

public class tf {
	static String tf_word[] = null;
	static String words[] = null;
    private class Word implements Comparable<Word>{
        String word;
        int count;
        public Word(String word, int count) {
            this.word = word;
            this.count = count;
        }
        
        public int compareTo(Word otherWord) {
            if(this.count==otherWord.count){
                return this.word.compareTo(otherWord.word);
            }
            return otherWord.count-this.count;
        }
    }

    private Word[] getFrequentWords(String words[]){
        HashMap<String,Word> map = new HashMap<String,Word>();
        for(String s:words){
            Word w = map.get(s);
            if(w==null)
                w = new Word(s,1);
            else
                w.count++;
            map.put(s, w);
        }
        Word[] list = map.values().toArray(new Word[]{});
        Arrays.sort(list);
        return list;
    }

    public static String[] main(String[] args) {
        words = args;
        int i = 0;
        Word[] frequency = new tf().getFrequentWords(words);
        tf_word = new String[words.length];
//        System.out.println(words.length);
        for(Word w:frequency){
        	
        	tf_word[i] = w.word+"="+w.count;
//        	System.out.println(w.word+"="+w.count);
        	i++;
        }
        
        return tf_word;
//        for (int k = 0; k < tf_word.length; k++){
//        	if(tf_word[k] != null){
//        		System.out.println(tf_word[k]);
//        	}
        }
    

}
