package kr.ac.kaist.swrc.jhannanum.demo;

public class DB1 {				//디비 연결전 설정 부분 
	private String M_Name;		//변수선언
	private String M_Age;
	private String M_Sex;
	private String M_Job;
	private String M_Birth;
	private String M_Grow;
	private String M_Cm;
	private String M_Kg;
	private String M_Body;
	private String M_Cloth;
	private String M_Item;
	private String M_Type;
	private String M_Habit;
	private String M_Route;
	private String Relation;
	private String Target;
	
	public DB1()
	{
		
	}
	
	public DB1(String M_Name,String M_Age,String M_Sex,String M_Job,String M_Birth,String M_Grow,String M_Cm,String M_Kg,String M_Body,String M_Cloth,String M_Item,String M_Type,String M_Habit,String M_Route,String Relation,String Target)
	{		//변수와 DB변수 연결
		super();
		this.M_Name=M_Name;
		this.M_Age=M_Age;
		this.M_Sex=M_Sex;
		this.M_Job=M_Job;
		this.M_Birth=M_Birth;
		this.M_Grow=M_Grow;
		this.M_Cm=M_Cm;
		this.M_Kg=M_Kg;
		this.M_Body=M_Body;
		this.M_Cloth=M_Cloth;
		this.M_Item=M_Item;
		this.M_Type=M_Type;
		this.M_Habit=M_Habit;
		this.M_Route=M_Route; //이미지 경로
		this.Relation = Relation;
		this.Target = Target;
	}
	
	//DB의 get,set 부분
	//Name
	public String get_M_Name()
	{
		return M_Name;
	}
	public void set_M_Name(String M_Name)
	{
		this.M_Name=M_Name;
	}
	//Age
	public String get_M_Age()
	{
		return M_Age;
	}
	public void set_M_Age(String M_Age)
	{
		this.M_Age=M_Age;
	}
	//Sex
	public String get_M_Sex()
	{
		return M_Sex;
	}
	public void set_M_Sex(String M_Sex)
	{
		this.M_Sex=M_Sex;
	}
	//Job
	public String get_M_Job()
	{
		return M_Job;
	}
	public void set_M_Job(String M_Job)
	{
		this.M_Job=M_Job;
	}
	//Birth
	public String get_M_Birth()
	{
		return M_Birth;
	}
	public void set_M_Birth(String M_Birth)
	{
		this.M_Birth=M_Birth;
	}
	//Grow
	public String get_M_Grow()
	{
		return M_Grow;
	}
	public void set_M_Grow(String M_Grow)
	{
		this.M_Grow=M_Grow;
	}
	//Cm
	public String get_M_Cm()
	{
		return M_Cm;
	}
	public void set_M_Cm(String M_Cm)
	{
		this.M_Cm=M_Cm;
	}
	//Kg
	public String get_M_Kg()
	{
		return M_Kg;
	}
	public void set_M_Kg(String M_Kg)
	{
		this.M_Kg=M_Kg;
	}
	//Body
	public String get_M_Body()
	{
		return M_Body;
	}
	public void set_M_Body(String M_Body)
	{
		this.M_Body=M_Body;
	}
	//Cloth
	public String get_M_Cloth()
	{
		return M_Cloth;
	}
	public void set_M_Cloth(String M_Cloth)
	{
		this.M_Cloth=M_Cloth;
	}
	//Item
	public String get_M_Item()
	{
		return M_Item;
	}
	public void set_M_Item(String M_Item)
	{
		this.M_Item=M_Item;
	}
	//Type
	public String get_M_Type()
	{
		return M_Type;
	}
	public void set_M_Type(String M_Type)
	{
		this.M_Type=M_Type;
	}
	//Habit
	public String get_M_Habit()
	{
		return M_Habit;
	}
	public void set_M_Habit(String M_Habit)
	{
		this.M_Habit=M_Habit;
	}
	//Route
		public String get_M_Route()
	{
		return M_Route;
	}
	public void set_M_Route(String M_Route)
	{
		this.M_Route=M_Route;
	}
	
	public String getRelation() {
		return Relation;
	}

	public void setRelation(String relation) {
		Relation = relation;
	}

	public String getTarget() {
		return Target;
	}

	public void setTarget(String target) {
		Target = target;
	}

	public String[] getRowData() //DB순서대로
	{
		String data[] = new String[16];
		data[0] = M_Name;
		data[1] = M_Age;
		data[2] = M_Sex;
		data[3] = M_Job;
		data[4] = M_Birth;
		data[5] = M_Grow;
		data[6] = M_Cm;
		data[7] = M_Kg;
		data[8] = M_Body;
		data[9] = M_Cloth;
		data[10] = M_Item;
		data[11] = M_Type;
		data[12] = M_Habit;
		data[13] = M_Route;
		data[14] = Relation;
		data[15] = Target;
		return data;
	}

}
