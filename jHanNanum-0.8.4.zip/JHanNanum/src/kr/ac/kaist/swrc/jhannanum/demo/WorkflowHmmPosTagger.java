/*  Copyright 2010, 2011 Semantic Web Research Center, KAIST

This file is part of JHanNanum.

JHanNanum is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

JHanNanum is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with JHanNanum.  If not, see <http://www.gnu.org/licenses/>   */

package kr.ac.kaist.swrc.jhannanum.demo;

import kr.ac.kaist.swrc.jhannanum.hannanum.Workflow;
import kr.ac.kaist.swrc.jhannanum.hannanum.WorkflowFactory;

/**
 * This is a demo program of HanNanum that helps users to utilize the HanNanum library easily.
 * It uses a predefined work flow for POS tagging, which is good for general use.<br>
 * <br>
 * It performs morphological analysis and POS tagging for a Korean document with the following procedure:<br>
 * 		1. Create a predefined work flow for morphological analysis and POS tagging.<br>
 * 		2. Activate the work flow in multi-thread mode.<br>
 * 		3. Analyze a document that consists of several sentences.<br>
 * 		4. Print the result on the console.<br>
 * 		5. Repeats the procedure 3~4 with activated work flow.<br>
 * 		6. Close the work flow.<br>
 * 
 * @author Sangwon Park (hudoni@world.kaist.ac.kr), CILab, SWRC, KAIST
 */
public class WorkflowHmmPosTagger {

	public static void main(String[] args) {
		Workflow workflow = WorkflowFactory.getPredefinedWorkflow(WorkflowFactory.WORKFLOW_HMM_POS_TAGGER);
		String str_test = new String();
		
		
		try {
			/* Activate the work flow in the thread mode */
			workflow.activateWorkflow(true);
			
			/* Analysis using the work flow */
			String document = "옛날 아귀 귀신이라는 큰 도적이 있었다.  그는 종종 이 세상에서 나와서 세상을 요란하게 하고 예쁜 여자를 납치해 가기도 하였다.  어떤 때 아귀 귀신이 임금님의 세 공주를 한꺼번에 납치하여 갔다.  임금님은 여러 신하에게 귀신 잡을 계획을 물어 보았으나, 신통한 계책을 말하는 사람이 없었다.  그런데 한 사람의 무신이 나와 자신이 그 일을 맡겠다고 하였다.. 임금님, 저의 집은 대대로 국록을 받고 있습니다.  제가 생명을 바쳐 그 은혜를 갚고자 합니다.  반드시 공주님을 구하여 오겠습니다. 임금님은 이를 허락하고, 세 공주를 구하면 그 중 막내 공주와 결혼시키겠다고 하였다.  무신은 여러 하인을 데리고 아귀 귀신의 소굴을 찾아 출발하였다. 그러나 천하를 돌아다녔으나 귀신의 소굴이 어느 곳에 있는지조차 알 수 없었다.  하루는 어느 산모퉁이에서 피곤한 몸을 잡시 쉬고 있는 동안에 깜박 잠이 들었다.  꿈에 머리가 하얀 노인이 나타나 다음과 같이 말하였다. 나는 이 산의 산신령이다.  네가 찾는 아귀 귀신의 소굴이 산의 저 쪽 산중에 있다.  그 산에 이상한 바위가 있는데, 그 바위를 들어내면 땅 속으로 들어가는 구멍이 있을 것이다. 노인은 말을 마치자 사라졌다. 무신은 산을 넘고 물을 건너, 꿈속의 노인이 말한 산까지 갔다.  거기에는 조그마한 구멍이 있었다.  무신은 하인들에게 튼튼한 새끼를 꼬게 하고, 광주리 하나를 얽게 하였다.  그리고 하인들에게 누가 이 광주리를 타고 내려가서 아귀 귀신의 동정을 살피고 오겠는가?하고 물었으나, 한 사람도 응답하는 사람이 없었다.  그는 한 하인에게 광주리를 타라고 명령하였다.  그리고 만일 도중에 위험한 일이 있으면 줄을 흔들어라.  그러면 줄을 끌어올리겠다.고 하였다.  그 사람은 조금 내려가자 줄을 흔들었다.  무서웠기 때문이었다.  다음 사람은 조금 더 내려간 곳에서 줄을 흔들었다.  할 수 없이 무신 자신이 내려가기로 하였다.  그는 구멍의 끝까지 내려갔다. 그의 눈앞에 넓고 신비한 세계가 펼쳐져 있었다.  그는 제일 큰집의 우물곁에 있는 버드나무 위에 올라가 동정을 살폈다.  조금 있으니 어여쁜 아가씨가 물동이를 이고 그 집에서 나왔다.  그 아가씨는 막내 공주였다.  공주가 물을 긷자, 무신은 나뭇잎을 한 줌 훑어서 물동이 위에 떨어뜨렸다.  공주는 물을 버리고 다시 길었다.  그는 다시 나뭇잎을 떨어뜨렸다. 세 번만에 공주는 머리를 저으면서, 나무 위를 쳐다보고 깜짝 놀라며 말하였다. 당신은 윗 세상 사람인데, 어떻게 이런 도적의 굴에 내려왔습니까? 무신은 나무에서 내려와 지금까지의 일을 얘기하였다.  그러자 공주는 이렇게 말하였다. 귀신의 집 문에는 사나운 문지기가 지키고 있습니다.  그러니 어떻게 그 집에 들어가 도적을 잡을 수 있겠습니까? 무신은 공주의 귀에 대고 다음과 같이 말하였다. 저는 다른 물건으로 변할 수 있는 능력을 가지고 있습니다.  제가 수박으로 변할 테니, 이렇게 이렇게 하여 주십시오. 무신이 열 걸음쯤 공중으로 뛰어오르자 수박으로 변하였다.  공주는 그것을 치맛자락에 싸서 문을 지나갔다.  문지기는 공주의 치맛자락을 조사하였으나 별로 의심하지 않았다. 그러나 아귀 귀신은 사람 냄새가 나니 웬일인가?하고 공주에게 야단을 치며 물었다.  공주는 태연하게 그럴 리가 있습니까? 아마 몸이 불편해서 그런가 봅니다.하고 속였다.  아귀 귀신은 마침 몸이 불편하여 누워 있었다. 공주들은 독한 술을 만들면서 도적의 병이 낫기를 기다렸다.  며칠 후에 공주들은 술을 거르고 돼지를 잡아 잔치를 벌였다. 이제 병환이 나았으므로 즐거운 마음에 이 자리를 만들었습니다.  오늘은 마음껏 노시지요. 공주들이 갖은 아양을 부리며 술을 권하자, 도적은 마음이 흐뭇하여 걸러 놓은 술을 모두 마셨다.  그리고 공주들의 소원을 들어 주겠다고 하였다.  공주들은 속으로 기뻐하면서 도적이 더욱 우쭐대도록 칭찬하면서 말하였다. 저희에게는 대감님과 함께 사는 것 외에는 소원이 없습니다.  그런데 대감님같이 이 세상에서 제일 강한 분도 죽는 수가 있습니까? 도적은 취한 상태에서 공주들의 칭찬을 듣자 의심하지 않고 대답해 주었다. 내 양 옆구리에는 비늘이 두 개씩 있는데, 그것을 떼어버리면 죽지.  그러나 그것을 뗄 놈이 세상에는 없지. 하하하하...... 도적은 껄걸 웃다가 쓰러져 코를 골면서 잠이 들었다. 수박에서 다시 사람으로 변한 무신은 도적의 옆구리에 있는 비늘을 칼로 베어 냈다.  그러자 도적의 머리는 떨어져 천장으로 올라가다가 다시 목에 붙으려고 하였다.  공주들이 재빨리 매운 재를 목에 뿌리자, 다시 붙지 못하였다.  무신은 먼저 공주를 올려 보내고 자신이 올라가려고 하였으나 하인들이 바위를 떨어뜨리고 자신들만 돌아갔다. 하인들은 공주를 데리고 임금님에게 갔다.  임금님은 큰 잔치를 베풀고 하인들을 칭찬하였다. 무신은 떨어지는 바위를 피하여 죽음은 면하였으나, 구멍을 빠져 나갈 방법이 없었다.  그 때 노인이 나타나 말 한 필을 주며 타라고 하였다.  무신이 말을 타자, 말은 눈 깜짝할 사이에 땅 위로 올라왔다. 공주들은 오랜만에 만난 부모와 이야기를 하느라 무신의 일을 잊고 있었다.  임금님은 약속대로 하인의 우두머리와 막내 공주를 혼인시키려고 큰 잔치를 열었다.  그 때, 무신이 들어와 임금님에게 지나온 일을 말하였다.  임금님은 하인들을 죽이고, 막내 공주와 무신을 결혼하게 하였다.\n";			
			workflow.analyze(document);
//			System.out.println(workflow.getResultOfDocument());
			str_test = workflow.getResultOfDocument();
			String li_str[] = str_test.split("\n");
			for(int i=1; i < li_str.length; i++){
				if (li_str[i].contains("nc") | li_str[i].contains("np")){
					System.out.println(li_str[i]);
				}
			}
			
			
			/* Once a work flow is activated, it can be used repeatedly. 
			document = "日時: 2010년 7월 30일 오후 1시\n"
				+ "場所: Coex Conference Room\n";
			
			workflow.analyze(document);
			System.out.println(workflow.getResultOfDocument());
			
			workflow.close();
			*/
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
		
		/* Shutdown the work flow */
		workflow.close();  	
	}
}